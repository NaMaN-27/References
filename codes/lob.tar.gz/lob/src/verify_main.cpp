// src/verify_main.cpp — the correctness gate.
//
// Three independent checks, in increasing order of how much they would have
// saved me:
//
//   1. HierBitmap against a std::set oracle, on random set/reset/scan traffic.
//      Bit-twiddling with three levels of summary and inclusive/exclusive
//      masks is exactly the kind of code that is 99% right, and the 1% is a
//      boundary at word index 0 or 63 that fires once every few million
//      messages.
//
//   2. Fast book against the std::map reference book, compared after EVERY
//      message: top of book, top-20 depth on both sides, live order count,
//      and a full state checksum at checkpoints. This is the check that
//      matters. An order book bug does not crash — the book stays plausible,
//      the strategy keeps quoting, and you find out from the P&L weeks later.
//
//   3. Queue-position agreement on a sample of live orders, because the
//      per-level FIFO ordering is invisible to an aggregate L2 comparison.
//      Two books can agree on every price and quantity while disagreeing
//      about who is first in the queue, and for a passive strategy that
//      difference is the entire edge.
//
// On divergence it prints the message index, the decoded message, and both
// books' state, then exits non-zero. Finding the first divergence is most of
// the debugging; a checksum mismatch reported only at end-of-day tells you
// nothing about where to look.

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <set>
#include <string>
#include <vector>

#include "lob/book.hpp"
#include "lob/itch.hpp"
#include "lob/refbook.hpp"

using namespace lob;

namespace {

constexpr std::size_t kDepthK = 20;
constexpr std::size_t kChecksumEvery = 25000;

// ---------------------------------------------------------------------------
// 1. Bitmap unit test against std::set
// ---------------------------------------------------------------------------
bool test_bitmap() {
    constexpr std::size_t kBits = 16;
    HierBitmap<kBits> bm;
    std::set<std::size_t> oracle;
    std::mt19937_64 rng(12345);

    const std::size_t N = HierBitmap<kBits>::kLevels;
    // Bias toward boundaries: index 0, 63, 64, 4095, 4096, N-1 are where the
    // masking is most likely to be wrong.
    std::vector<std::size_t> hot = {0, 1, 62, 63, 64, 65, 4094, 4095, 4096,
                                    4097, N - 2, N - 1};

    for (int iter = 0; iter < 400000; ++iter) {
        std::size_t i;
        if (rng() % 4 == 0) i = hot[rng() % hot.size()];
        else                i = rng() % N;

        if (rng() % 2) { bm.set(i);   oracle.insert(i); }
        else           { bm.reset(i); oracle.erase(i); }

        if (iter % 97 == 0) {
            const std::size_t from = rng() % N;

            // highest at or below
            auto it = oracle.upper_bound(from);
            const std::size_t want_hi = (it == oracle.begin())
                                      ? HierBitmap<kBits>::kNone : *std::prev(it);
            const std::size_t got_hi = bm.highest_at_or_below(from);
            if (got_hi != want_hi) {
                std::printf("  [FAIL] bitmap highest_at_or_below(%zu): got %zu want %zu\n",
                            from, got_hi, want_hi);
                return false;
            }

            // lowest at or above
            auto it2 = oracle.lower_bound(from);
            const std::size_t want_lo = (it2 == oracle.end())
                                      ? HierBitmap<kBits>::kNone : *it2;
            const std::size_t got_lo = bm.lowest_at_or_above(from);
            if (got_lo != want_lo) {
                std::printf("  [FAIL] bitmap lowest_at_or_above(%zu): got %zu want %zu\n",
                            from, got_lo, want_lo);
                return false;
            }

            if (bm.popcount() != oracle.size()) {
                std::printf("  [FAIL] bitmap popcount %zu vs %zu\n",
                            bm.popcount(), oracle.size());
                return false;
            }
        }
    }
    std::printf("  [ OK ] HierBitmap vs std::set   400000 ops, boundary-weighted\n");
    return true;
}

// ---------------------------------------------------------------------------
// 2. Differential handler
// ---------------------------------------------------------------------------
struct DiffHandler {
    Book<16>&  fast;
    RefBook&   ref;
    std::size_t idx{0};
    std::size_t divergences{0};
    std::size_t checksums_checked{0};
    std::size_t queue_checks{0};
    std::uint64_t length_mismatches{0};
    std::vector<std::uint64_t> sample_refs;

    std::vector<BookLevel> fd, rd;

    void on_length_mismatch(std::uint8_t, std::uint16_t, std::uint16_t) noexcept {
        ++length_mismatches;
    }

    void on_add(const itch::AddOrder& a, const std::uint8_t*) {
        fast.add(a.ref, a.is_buy, a.shares, a.price);
        ref.add(a.ref, a.is_buy, a.shares, a.price);
        if (sample_refs.size() < 4096 && (idx & 511) == 0) sample_refs.push_back(a.ref);
        step("add");
    }
    void on_executed(const itch::Executed& e, const std::uint8_t*, bool) {
        fast.execute(e.ref, e.shares);
        ref.execute(e.ref, e.shares);
        step("execute");
    }
    void on_cancel(const itch::Cancel& c, const std::uint8_t*) {
        fast.cancel(c.ref, c.shares);
        ref.cancel(c.ref, c.shares);
        step("cancel");
    }
    void on_delete(const itch::Delete& d, const std::uint8_t*) {
        fast.remove(d.ref);
        ref.remove(d.ref);
        step("delete");
    }
    void on_replace(const itch::Replace& r, const std::uint8_t*) {
        fast.replace(r.old_ref, r.new_ref, r.shares, r.price);
        ref.replace(r.old_ref, r.new_ref, r.shares, r.price);
        step("replace");
    }
    void on_other(std::uint8_t, const std::uint8_t*, std::uint16_t) { ++idx; }

    void step(const char* what) {
        ++idx;
        if (divergences) return;

        // --- top of book, every message ---
        const TopOfBook ft = fast.top(), rt = ref.top();
        if (!(ft == rt)) {
            report(what, "top of book");
            std::printf("    fast  bid %u x %u | ask %u x %u\n",
                        ft.bid_px, ft.bid_qty, ft.ask_px, ft.ask_qty);
            std::printf("    ref   bid %u x %u | ask %u x %u\n",
                        rt.bid_px, rt.bid_qty, rt.ask_px, rt.ask_qty);
            return;
        }

        // --- live order count, every message ---
        if (fast.live_orders() != ref.live_orders()) {
            report(what, "live order count");
            std::printf("    fast %zu   ref %zu\n", fast.live_orders(), ref.live_orders());
            return;
        }

        // --- top-K depth, every message, both sides ---
        for (int side = 0; side < 2; ++side) {
            const bool buy = (side == 0);
            fast.depth(buy, kDepthK, fd);
            ref.depth(buy, kDepthK, rd);
            if (fd.size() != rd.size()) {
                report(what, buy ? "bid depth size" : "ask depth size");
                std::printf("    fast %zu levels   ref %zu levels\n", fd.size(), rd.size());
                return;
            }
            for (std::size_t i = 0; i < fd.size(); ++i) {
                if (fd[i].price != rd[i].price || fd[i].qty != rd[i].qty ||
                    fd[i].count != rd[i].count) {
                    report(what, buy ? "bid depth" : "ask depth");
                    std::printf("    level %zu:  fast px=%u qty=%u n=%u | ref px=%u qty=%u n=%u\n",
                                i, fd[i].price, fd[i].qty, fd[i].count,
                                rd[i].price, rd[i].qty, rd[i].count);
                    return;
                }
            }
        }

        // --- full checksum + queue positions, at checkpoints ---
        if (idx % kChecksumEvery == 0) {
            ++checksums_checked;
            const std::uint64_t fc = fast.checksum(), rc = ref.checksum();
            if (fc != rc) {
                report(what, "full book checksum");
                std::printf("    fast 0x%016llx   ref 0x%016llx\n",
                            (unsigned long long)fc, (unsigned long long)rc);
                std::printf("    (top-20 agreed, so the divergence is deeper than level 20)\n");
                return;
            }
            for (std::uint64_t r : sample_refs) {
                const std::uint64_t fa = fast.shares_ahead(r);
                const std::uint64_t ra = ref.shares_ahead(r);
                ++queue_checks;
                if (fa != ra) {
                    report(what, "queue position");
                    std::printf("    order %llu: fast %llu shares ahead, ref %llu\n",
                                (unsigned long long)r,
                                (unsigned long long)fa, (unsigned long long)ra);
                    return;
                }
            }
        }
    }

    void report(const char* what, const char* field) {
        ++divergences;
        std::printf("\n  [FAIL] divergence at message %zu (%s) — %s\n", idx, what, field);
    }
};

}  // namespace

int main(int argc, char** argv) {
    const std::string path = argc > 1 ? argv[1] : "data/synth.itch";

    std::printf("LOB verification\n");
    std::printf("================\n");

    if (!test_bitmap()) return 1;

    itch::MappedFile f(path);
    if (!f.ok()) { std::printf("  cannot open %s — run `make data` first\n", path.c_str()); return 1; }

    Book<16> fast(1u << 21, 22, 0, 100);
    RefBook  ref(0, 100, 1u << 16);
    DiffHandler h{fast, ref, 0, 0, 0, 0, 0, {}, {}, {}};

    bool truncated = false;
    const std::size_t n = itch::parse(f.data(), f.size(), h, &truncated);

    if (h.divergences) {
        std::printf("\nFAST BOOK DISAGREES WITH REFERENCE — do not trust any benchmark.\n");
        return 1;
    }

    std::printf("  [ OK ] top-of-book             %zu messages, checked every message\n", n);
    std::printf("  [ OK ] top-%zu depth both sides %zu messages, checked every message\n", kDepthK, n);
    std::printf("  [ OK ] live order count        %zu messages, checked every message\n", n);
    std::printf("  [ OK ] full book checksum      %zu checkpoints\n", h.checksums_checked);
    std::printf("  [ OK ] queue position (FIFO)   %zu order comparisons\n", h.queue_checks);

    const auto& s = fast.stats();
    std::printf("\nbook state at end of file\n");
    std::printf("  messages parsed    : %zu%s\n", n, truncated ? "  (FILE TRUNCATED)" : "");
    std::printf("  add / delete       : %llu / %llu\n",
                (unsigned long long)s.adds, (unsigned long long)s.deletes);
    std::printf("  cancel / execute   : %llu / %llu\n",
                (unsigned long long)s.cancels, (unsigned long long)s.executes);
    std::printf("  replace            : %llu\n", (unsigned long long)s.replaces);
    std::printf("  executed shares    : %llu\n", (unsigned long long)s.exec_shares);
    std::printf("  live orders        : %zu  (ref %zu)\n", fast.live_orders(), ref.live_orders());
    std::printf("  price levels       : %zu bid / %zu ask  (ref %zu / %zu)\n",
                fast.bid_levels(), fast.ask_levels(), ref.bid_levels(), ref.ask_levels());
    std::printf("  pool high water    : %zu orders\n", fast.pool_high_water());
    std::printf("  hash avg probes    : %.3f  (load factor %.3f)\n",
                fast.order_map().avg_probes(), fast.order_map().load_factor());
    std::printf("  best-price rescans : %llu  (%.2f%% of messages)\n",
                (unsigned long long)s.best_recomputes,
                100.0 * static_cast<double>(s.best_recomputes) / static_cast<double>(n));
    std::printf("  final checksum     : 0x%016llx\n", (unsigned long long)fast.checksum());

    std::printf("\nanomaly counters (all should be 0 on a clean feed)\n");
    std::printf("  unknown order ref  : %llu\n", (unsigned long long)s.unknown_ref);
    std::printf("  price out of range : %llu\n", (unsigned long long)s.price_out_of_range);
    std::printf("  pool exhausted     : %llu\n", (unsigned long long)s.pool_exhausted);
    std::printf("  length mismatches  : %llu\n", (unsigned long long)h.length_mismatches);

    std::printf("\nALL CHECKS PASSED — fast book is equivalent to the reference.\n");
    return 0;
}
