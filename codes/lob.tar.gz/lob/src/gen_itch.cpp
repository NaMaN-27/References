// src/gen_itch.cpp — generate a spec-conformant ITCH 5.0 BinaryFILE.
//
// Why generate instead of just downloading
// ----------------------------------------
// Nasdaq publishes free daily TotalView-ITCH samples and this project consumes
// them directly (see README). A generated file adds three things a downloaded
// one cannot:
//
//   1. Determinism. A fixed seed produces byte-identical input, which is what
//      makes "replay twice, get the same checksum" a statement about the book
//      rather than about your disk.
//   2. Adversarial control. Real data does not contain a 500-deep price level
//      or a sweep that empties 400 levels on demand. Those are exactly the
//      cases that break a book which finds its best price by scanning.
//   3. No multi-GB download in CI.
//
// The market model, and a mistake worth documenting
// -------------------------------------------------
// The first version of this generator kept live orders in a flat vector and
// cleared "crossed" orders by sampling a few at random each iteration. That
// does not work, and the way it fails is instructive: the mid random-walks
// away, stale orders on the wrong side accumulate faster than random sampling
// removes them, and within a million messages the best bid sits 2000 ticks
// ABOVE the best ask. A persistently crossed book is not a market — and worse,
// the touch level then never empties, so best-price recomputation never fires
// and the occupancy bitmap goes entirely untested by a file that looks fine.
// The verifier passed the whole time. Only the "best-price rescans: 0.00% of
// messages" counter gave it away.
//
// So the generator now carries a real price-indexed book: price -> FIFO of
// order references, per side. When the mid moves, every level now through the
// market is cleared explicitly, order by order, as executions and cancels.
// That is the actual mechanism in a real market, and it produces a book that
// is never crossed, has a touch that churns constantly, and exercises the code
// paths this project exists to test.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <list>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

#include "lob/itch.hpp"

using namespace lob::itch;

namespace {

class Rng {
public:
    explicit Rng(std::uint64_t seed) noexcept { for (auto& x : s_) x = splitmix(seed); }
    std::uint64_t next() noexcept {
        const std::uint64_t r = rotl(s_[1] * 5, 7) * 9;
        const std::uint64_t t = s_[1] << 17;
        s_[2] ^= s_[0]; s_[3] ^= s_[1]; s_[1] ^= s_[2]; s_[0] ^= s_[3];
        s_[2] ^= t;     s_[3]  = rotl(s_[3], 45);
        return r;
    }
    double uniform() noexcept { return static_cast<double>(next() >> 11) * 0x1.0p-53; }
    std::uint32_t below(std::uint32_t n) noexcept {
        return n ? static_cast<std::uint32_t>(next() % n) : 0;
    }
    double normal() noexcept {
        double u1 = uniform(); if (u1 < 1e-300) u1 = 1e-300;
        return std::sqrt(-2.0 * std::log(u1)) * std::cos(6.283185307179586 * uniform());
    }
private:
    static std::uint64_t rotl(std::uint64_t x, int k) noexcept { return (x << k) | (x >> (64 - k)); }
    static std::uint64_t splitmix(std::uint64_t& x) noexcept {
        std::uint64_t z = (x += 0x9E3779B97F4A7C15ULL);
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
        return z ^ (z >> 31);
    }
    std::uint64_t s_[4]{};
};

// Price-indexed model of the book the generator is describing. Correctness and
// clarity only — this runs once, offline, and is on no hot path anywhere.
class Model {
public:
    struct Info {
        std::uint32_t price;
        std::uint32_t qty;
        bool          is_buy;
        std::list<std::uint64_t>::iterator it;
        std::size_t   vec_pos;      // index into refs_, for O(1) random pick
    };

    void add(std::uint64_t ref, std::uint32_t price, std::uint32_t qty, bool is_buy) {
        auto& side = is_buy ? bids_ : asks_;
        auto& lst = side[price];
        lst.push_back(ref);
        refs_.push_back(ref);
        info_[ref] = Info{price, qty, is_buy, std::prev(lst.end()), refs_.size() - 1};
    }

    void erase(std::uint64_t ref) {
        auto it = info_.find(ref);
        if (it == info_.end()) return;
        auto& side = it->second.is_buy ? bids_ : asks_;
        auto lit = side.find(it->second.price);
        if (lit != side.end()) {
            lit->second.erase(it->second.it);
            if (lit->second.empty()) side.erase(lit);
        }
        const std::size_t pos = it->second.vec_pos;   // O(1) swap-remove
        refs_[pos] = refs_.back();
        info_[refs_[pos]].vec_pos = pos;
        refs_.pop_back();
        info_.erase(ref);
    }

    Info* find(std::uint64_t ref) {
        auto it = info_.find(ref);
        return it == info_.end() ? nullptr : &it->second;
    }
    std::uint64_t random_ref(Rng& r) const {
        return refs_.empty() ? 0 : refs_[r.below(static_cast<std::uint32_t>(refs_.size()))];
    }
    std::size_t size()  const { return refs_.size(); }
    bool        empty() const { return refs_.empty(); }

    std::uint32_t best_bid() const { return bids_.empty() ? 0 : bids_.rbegin()->first; }
    std::uint32_t best_ask() const { return asks_.empty() ? 0 : asks_.begin()->first; }

    // Copied, because the caller erases as it walks.
    std::vector<std::uint64_t> level_refs(std::uint32_t price, bool is_buy) const {
        const auto& side = is_buy ? bids_ : asks_;
        auto it = side.find(price);
        if (it == side.end()) return {};
        return std::vector<std::uint64_t>(it->second.begin(), it->second.end());
    }
    // n-th best price on a side, 0 if absent. Used by the sweep generator.
    std::uint32_t nth_price(std::size_t n, bool is_buy) const {
        if (is_buy) {
            auto it = bids_.rbegin();
            for (std::size_t i = 0; i < n && it != bids_.rend(); ++i) ++it;
            return it == bids_.rend() ? 0 : it->first;
        }
        auto it = asks_.begin();
        for (std::size_t i = 0; i < n && it != asks_.end(); ++i) ++it;
        return it == asks_.end() ? 0 : it->first;
    }
    std::size_t bid_levels() const { return bids_.size(); }
    std::size_t ask_levels() const { return asks_.size(); }

private:
    std::map<std::uint32_t, std::list<std::uint64_t>> bids_, asks_;
    std::unordered_map<std::uint64_t, Info>           info_;
    std::vector<std::uint64_t>                        refs_;
};

class Writer {
public:
    explicit Writer(std::size_t reserve_bytes) { buf_.reserve(reserve_bytes); }
    std::uint8_t* begin_msg(std::uint16_t body_len) {
        const std::size_t at = buf_.size();
        buf_.resize(at + 2 + body_len);
        wr_be16(buf_.data() + at, body_len);
        return buf_.data() + at + 2;
    }
    static void header(std::uint8_t* m, std::uint8_t type, std::uint16_t locate,
                       std::uint16_t tracking, std::uint64_t ts) {
        m[0] = type;
        wr_be16(m + 1, locate);
        wr_be16(m + 3, tracking);
        wr_be48(m + 5, ts);
    }
    bool flush(const std::string& path) const {
        std::FILE* f = std::fopen(path.c_str(), "wb");
        if (!f) return false;
        const bool ok = std::fwrite(buf_.data(), 1, buf_.size(), f) == buf_.size();
        std::fclose(f);
        return ok;
    }
    std::size_t bytes() const { return buf_.size(); }
private:
    std::vector<std::uint8_t> buf_;
};

void put_stock(std::uint8_t* p, const char* sym) {
    std::memset(p, ' ', 8);
    const std::size_t n = std::min<std::size_t>(std::strlen(sym), 8);
    std::memcpy(p, sym, n);
}

}  // namespace

int main(int argc, char** argv) {
    const std::string   out    = argc > 1 ? argv[1] : "data/synth.itch";
    const std::size_t   target = argc > 2 ? std::strtoull(argv[2], nullptr, 10) : 5000000;
    const std::uint64_t seed   = argc > 3 ? std::strtoull(argv[3], nullptr, 10) : 20240603;

    Rng rng(seed);
    Writer w(target * 34);
    Model model;

    const char* kSymbol = "SYNTH";
    const std::uint16_t kLocate = 1;
    const std::uint32_t tick = 100;                 // one cent, in 1/10000 units
    std::uint64_t ts = 34200ULL * 1000000000ULL;    // 09:30:00
    std::uint64_t next_ref = 1, next_match = 1;
    double mid = 1000000.0;                         // $100.00

    std::size_t n_add = 0, n_del = 0, n_can = 0, n_exe = 0, n_rep = 0, n_trd = 0;
    std::size_t sweeps = 0, pileups = 0, cleared = 0;

    auto total = [&] { return n_add + n_del + n_can + n_exe + n_rep + n_trd; };
    auto tick_time = [&] { ts += 150ULL + static_cast<std::uint64_t>(rng.uniform() * 30000.0); };

    { std::uint8_t* m = w.begin_msg(12); Writer::header(m, kSystemEvent, 0, 0, ts); m[11] = 'O'; }
    {
        std::uint8_t* m = w.begin_msg(39);
        Writer::header(m, kStockDirectory, kLocate, 0, ts);
        put_stock(m + 11, kSymbol);
        m[19] = 'Q'; m[20] = 'N';
        wr_be32(m + 21, 100);
        m[25] = 'N'; m[26] = 'C';
        wr_be16(m + 27, 0);
        m[29] = 'P'; m[30] = 'N'; m[31] = 'N'; m[32] = ' '; m[33] = 'N';
        wr_be32(m + 34, 0);
        m[38] = 'N';
    }
    { std::uint8_t* m = w.begin_msg(12); Writer::header(m, kSystemEvent, 0, 0, ts); m[11] = 'Q'; }

    auto emit_add = [&](std::uint32_t price, bool is_buy, std::uint32_t shares) {
        std::uint8_t* m = w.begin_msg(36);
        Writer::header(m, kAddOrder, kLocate, 0, ts);
        wr_be64(m + 11, next_ref);
        m[19] = is_buy ? 'B' : 'S';
        wr_be32(m + 20, shares);
        put_stock(m + 24, kSymbol);
        wr_be32(m + 32, price);
        model.add(next_ref, price, shares, is_buy);
        ++next_ref;
        ++n_add;
    };
    auto emit_delete = [&](std::uint64_t ref) {
        std::uint8_t* m = w.begin_msg(19);
        Writer::header(m, kOrderDelete, kLocate, 0, ts);
        wr_be64(m + 11, ref);
        model.erase(ref);
        ++n_del;
    };
    auto emit_execute = [&](std::uint64_t ref, std::uint32_t shares, bool with_price) {
        auto* inf = model.find(ref);
        if (!inf) return;
        const std::uint32_t take = std::min(shares, inf->qty);
        if (with_price) {
            std::uint8_t* m = w.begin_msg(36);
            Writer::header(m, kOrderExecutedPx, kLocate, 0, ts);
            wr_be64(m + 11, ref);
            wr_be32(m + 19, take);
            wr_be64(m + 23, next_match++);
            m[31] = 'Y';
            wr_be32(m + 32, inf->price);
        } else {
            std::uint8_t* m = w.begin_msg(31);
            Writer::header(m, kOrderExecuted, kLocate, 0, ts);
            wr_be64(m + 11, ref);
            wr_be32(m + 19, take);
            wr_be64(m + 23, next_match++);
        }
        inf->qty -= take;
        if (inf->qty == 0) model.erase(ref);
        ++n_exe;
    };

    // Resting price: exponentially distributed distance from the mid, so the
    // book is dense at the touch and thins out with depth — which is what makes
    // best-price recomputation cheap most of the time and expensive exactly
    // when the market is moving.
    auto pick_price = [&](bool is_buy) -> std::uint32_t {
        double u = rng.uniform();
        if (u < 1e-12) u = 1e-12;
        const auto depth = static_cast<std::uint32_t>(-std::log(u) * 8.0);
        const auto m_tick = static_cast<std::int64_t>(mid / tick);
        std::int64_t lvl = is_buy ? (m_tick - 1 - depth) : (m_tick + 1 + depth);
        if (lvl < 1) lvl = 1;
        return static_cast<std::uint32_t>(lvl) * tick;
    };

    // Clear every level the market has moved through. Keeps the book uncrossed
    // and the touch churning, which is what makes the rest of the test real.
    auto clear_through_market = [&] {
        for (int guard = 0; guard < 128; ++guard) {
            const std::uint32_t bb = model.best_bid();
            const std::uint32_t ba = model.best_ask();
            const bool bid_through = bb != 0 && static_cast<double>(bb) > mid;
            const bool ask_through = ba != 0 && static_cast<double>(ba) < mid;
            if (!bid_through && !ask_through) break;
            const bool do_bid = bid_through;
            const std::uint32_t px = do_bid ? bb : ba;
            for (std::uint64_t r : model.level_refs(px, do_bid)) {
                tick_time();
                auto* inf = model.find(r);
                if (!inf) continue;
                if (rng.uniform() < 0.55) emit_execute(r, inf->qty, rng.uniform() < 0.15);
                else                      emit_delete(r);
                ++cleared;
            }
        }
    };

    for (int i = 0; i < 30000; ++i) {          // seed a book
        tick_time();
        const bool buy = (i % 2) == 0;
        emit_add(pick_price(buy), buy, 100 * (1 + rng.below(20)));
    }

    while (total() < target) {
        tick_time();

        mid *= std::exp(0.000006 * rng.normal());
        if (rng.uniform() < 0.00003) mid *= std::exp(0.005 * rng.normal());
        clear_through_market();

        const double u = rng.uniform();

        // Adversarial case 1: a sweep that empties a long contiguous run of
        // levels in one burst. The worst case for a scanning best-price search
        // and the reason the occupancy bitmap exists.
        if (u > 0.9999 && model.size() > 4000) {
            ++sweeps;
            const bool side = rng.uniform() < 0.5;
            std::size_t done = 0;
            for (std::size_t lvl = 0; lvl < 200 && done < 600; ++lvl) {
                const std::uint32_t px = model.nth_price(0, side);   // always the touch
                if (px == 0) break;
                for (std::uint64_t r : model.level_refs(px, side)) {
                    tick_time();
                    emit_delete(r);
                    if (++done >= 600) break;
                }
            }
            continue;
        }

        // Adversarial case 2: pile many orders onto one price, to stress the
        // per-level FIFO list and the queue-position walk.
        if (u > 0.99975 && u <= 0.9999) {
            ++pileups;
            const bool buy = rng.uniform() < 0.5;
            const std::uint32_t px = pick_price(buy);
            for (int k = 0; k < 500; ++k) { tick_time(); emit_add(px, buy, 100); }
            continue;
        }

        if (model.empty() || u < 0.58) {
            const bool buy = rng.uniform() < 0.5;
            emit_add(pick_price(buy), buy, 100 * (1 + rng.below(30)));
            continue;
        }

        const std::uint64_t ref = model.random_ref(rng);
        auto* inf = model.find(ref);
        if (!inf) continue;

        if (u < 0.84) {                       // full delete — the common fate
            emit_delete(ref);

        } else if (u < 0.90) {                // partial cancel
            const std::uint32_t cut = 100 * (1 + rng.below(std::max(1u, inf->qty / 100)));
            const std::uint32_t take = std::min(cut, inf->qty);
            std::uint8_t* m = w.begin_msg(23);
            Writer::header(m, kOrderCancel, kLocate, 0, ts);
            wr_be64(m + 11, ref);
            wr_be32(m + 19, take);
            inf->qty -= take;
            if (inf->qty == 0) model.erase(ref);
            ++n_can;

        } else if (u < 0.94) {                // execution against a resting order
            emit_execute(ref, 100u * (1 + rng.below(5)), rng.uniform() < 0.15);

        } else if (u < 0.99) {                // replace (loses time priority)
            const std::uint32_t new_px = pick_price(inf->is_buy);
            const std::uint32_t new_qty = 100 * (1 + rng.below(30));
            const bool is_buy = inf->is_buy;
            std::uint8_t* m = w.begin_msg(35);
            Writer::header(m, kOrderReplace, kLocate, 0, ts);
            wr_be64(m + 11, ref);
            wr_be64(m + 19, next_ref);
            wr_be32(m + 27, new_qty);
            wr_be32(m + 31, new_px);
            model.erase(ref);
            model.add(next_ref, new_px, new_qty, is_buy);
            ++next_ref;
            ++n_rep;

        } else {                              // non-displayable trade, no book effect
            std::uint8_t* m = w.begin_msg(44);
            Writer::header(m, kTrade, kLocate, 0, ts);
            wr_be64(m + 11, 0);
            m[19] = 'B';
            wr_be32(m + 20, 100 * (1 + rng.below(10)));
            put_stock(m + 24, kSymbol);
            wr_be32(m + 32, static_cast<std::uint32_t>(mid));
            wr_be64(m + 36, next_match++);
            ++n_trd;
        }
    }

    { std::uint8_t* m = w.begin_msg(12); Writer::header(m, kSystemEvent, 0, 0, ts); m[11] = 'M'; }

    if (!w.flush(out)) { std::fprintf(stderr, "failed to write %s\n", out.c_str()); return 1; }

    const double t = static_cast<double>(total());
    std::printf("wrote %s\n", out.c_str());
    std::printf("  bytes            : %.1f MB\n", static_cast<double>(w.bytes()) / (1024.0 * 1024.0));
    std::printf("  messages         : %zu\n", total());
    std::printf("  add              : %8zu  (%5.1f%%)\n", n_add, 100.0 * static_cast<double>(n_add) / t);
    std::printf("  delete           : %8zu  (%5.1f%%)\n", n_del, 100.0 * static_cast<double>(n_del) / t);
    std::printf("  cancel (partial) : %8zu  (%5.1f%%)\n", n_can, 100.0 * static_cast<double>(n_can) / t);
    std::printf("  execute          : %8zu  (%5.1f%%)\n", n_exe, 100.0 * static_cast<double>(n_exe) / t);
    std::printf("  replace          : %8zu  (%5.1f%%)\n", n_rep, 100.0 * static_cast<double>(n_rep) / t);
    std::printf("  trade (hidden)   : %8zu  (%5.1f%%)\n", n_trd, 100.0 * static_cast<double>(n_trd) / t);
    std::printf("  resting at close : %zu orders across %zu bid / %zu ask levels\n",
                model.size(), model.bid_levels(), model.ask_levels());
    std::printf("  cleared through  : %zu orders taken out by market moves\n", cleared);
    std::printf("  stress events    : %zu sweeps, %zu deep-level pileups\n", sweeps, pileups);
    std::printf("  seed             : %llu\n", static_cast<unsigned long long>(seed));
    return 0;
}
