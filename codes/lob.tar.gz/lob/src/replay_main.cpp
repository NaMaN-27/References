// src/replay_main.cpp — deterministic replay.
//
// What "deterministic" has to mean here
// -------------------------------------
// Replaying the same capture must produce the same book state, every time, on
// every machine, in every build configuration. That sounds obvious and is
// routinely violated, usually by one of four things:
//
//   1. Floating point. Prices held as double reassociate differently under
//      -O3 or -ffast-math than under -O0, and the book drifts in the fourth
//      decimal. This book never converts a price to floating point — ITCH
//      gives integers with four implied decimals and they stay integers.
//   2. Iteration order of an unordered container leaking into output.
//   3. Uninitialised memory read as padding into a checksum.
//   4. Pointer values or allocation addresses influencing behaviour (a hash
//      keyed on a pointer, say). ASLR then makes every run different.
//
// The checkpoint checksums here catch all four. They are FNV-1a over the full
// occupied ladder (price, quantity, order count per level, both sides), taken
// at fixed message intervals — not just at end of day. An end-of-day-only
// checksum tells you that something diverged, and nothing about where; a
// checkpoint series bisects it for you immediately.
//
// The golden file
// ---------------
// First run writes it. Subsequent runs compare against it and fail loudly on
// the first differing checkpoint. Commit the golden file. It is the cheapest
// possible regression test: any refactor that changes book semantics — even a
// subtle one, even one that keeps the top of book identical — fails the
// instant it changes any level's quantity anywhere in the ladder.

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "lob/book.hpp"
#include "lob/clock.hpp"
#include "lob/itch.hpp"

using namespace lob;

namespace {

constexpr std::size_t kCheckpointEvery = 100000;

struct Checkpoint {
    std::size_t   msg_index;
    std::uint64_t checksum;
    std::uint32_t bid_px, bid_qty, ask_px, ask_qty;
};

struct ReplayHandler {
    Book<16>&               book;
    std::vector<Checkpoint> checkpoints;
    std::size_t             idx{0};
    std::size_t             tob_changes{0};
    TopOfBook               last_tob{};
    std::uint64_t           first_ts{0}, last_ts{0};
    std::uint64_t           length_mismatches{0};

    void on_length_mismatch(std::uint8_t, std::uint16_t, std::uint16_t) noexcept {
        ++length_mismatches;
    }
    void on_add(const itch::AddOrder& a, const std::uint8_t* m) noexcept {
        book.add(a.ref, a.is_buy, a.shares, a.price); post(m);
    }
    void on_executed(const itch::Executed& e, const std::uint8_t* m, bool) noexcept {
        book.execute(e.ref, e.shares); post(m);
    }
    void on_cancel(const itch::Cancel& c, const std::uint8_t* m) noexcept {
        book.cancel(c.ref, c.shares); post(m);
    }
    void on_delete(const itch::Delete& d, const std::uint8_t* m) noexcept {
        book.remove(d.ref); post(m);
    }
    void on_replace(const itch::Replace& r, const std::uint8_t* m) noexcept {
        book.replace(r.old_ref, r.new_ref, r.shares, r.price); post(m);
    }
    void on_other(std::uint8_t, const std::uint8_t* m, std::uint16_t) noexcept {
        post(m);
    }

    void post(const std::uint8_t* m) noexcept {
        const std::uint64_t ts = itch::msg_timestamp(m);
        if (first_ts == 0) first_ts = ts;
        last_ts = ts;
        ++idx;

        const TopOfBook t = book.top();
        if (!(t == last_tob)) { ++tob_changes; last_tob = t; }

        if (idx % kCheckpointEvery == 0)
            checkpoints.push_back({idx, book.checksum(),
                                   t.bid_px, t.bid_qty, t.ask_px, t.ask_qty});
    }
};

bool write_golden(const std::string& path, const std::vector<Checkpoint>& cps,
                  std::uint64_t final_sum) {
    if (path == "/dev/null") return true;
    std::FILE* f = std::fopen(path.c_str(), "w");
    if (!f) return false;
    std::fprintf(f, "# lob golden checkpoints — regenerate only when book semantics change\n");
    std::fprintf(f, "# msg_index checksum bid_px bid_qty ask_px ask_qty\n");
    for (const auto& c : cps)
        std::fprintf(f, "%zu %016llx %u %u %u %u\n", c.msg_index,
                     (unsigned long long)c.checksum, c.bid_px, c.bid_qty,
                     c.ask_px, c.ask_qty);
    std::fprintf(f, "FINAL %016llx\n", (unsigned long long)final_sum);
    std::fclose(f);
    return true;
}

bool read_golden(const std::string& path, std::vector<Checkpoint>& cps,
                 std::uint64_t& final_sum) {
    std::FILE* f = std::fopen(path.c_str(), "r");
    if (!f) return false;
    char line[256];
    while (std::fgets(line, sizeof(line), f)) {
        if (line[0] == '#') continue;
        if (std::strncmp(line, "FINAL", 5) == 0) {
            std::sscanf(line + 5, "%llx", (unsigned long long*)&final_sum);
            continue;
        }
        Checkpoint c{};
        unsigned long long sum = 0;
        if (std::sscanf(line, "%zu %llx %u %u %u %u", &c.msg_index, &sum,
                        &c.bid_px, &c.bid_qty, &c.ask_px, &c.ask_qty) == 6) {
            c.checksum = sum;
            cps.push_back(c);
        }
    }
    std::fclose(f);
    return true;
}

std::size_t run(const itch::MappedFile& f, ReplayHandler& h) {
    bool truncated = false;
    return itch::parse(f.data(), f.size(), h, &truncated);
}

}  // namespace

int main(int argc, char** argv) {
    const std::string path   = argc > 1 ? argv[1] : "data/synth.itch";
    const std::string golden = argc > 2 ? argv[2] : "results/golden.txt";

    itch::MappedFile f(path);
    if (!f.ok()) { std::printf("cannot open %s — run `make data` first\n", path.c_str()); return 1; }
    f.prefault();

    const double ghz = calibrate_tsc_ghz();

    std::printf("LOB deterministic replay\n");
    std::printf("========================\n");
    std::printf("  file          : %s (%.1f MB)\n", path.c_str(),
                static_cast<double>(f.size()) / (1024.0 * 1024.0));

    // ---- pass 1 -----------------------------------------------------------
    Book<16> b1(1u << 21, 22, 0, 100);
    ReplayHandler h1{b1, {}, 0, 0, {}, 0, 0, 0};
    const std::uint64_t t0 = tsc_begin();
    const std::size_t n1 = run(f, h1);
    const std::uint64_t t1 = tsc_end();

    // ---- pass 2, a fresh book over the same bytes -------------------------
    Book<16> b2(1u << 21, 22, 0, 100);
    ReplayHandler h2{b2, {}, 0, 0, {}, 0, 0, 0};
    const std::size_t n2 = run(f, h2);

    const std::uint64_t s1 = b1.checksum(), s2 = b2.checksum();

    std::printf("  messages      : %zu\n", n1);
    std::printf("  session       : %.6f s of market time\n",
                static_cast<double>(h1.last_ts - h1.first_ts) / 1e9);
    const double ns_total = static_cast<double>(t1 - t0) / ghz;
    std::printf("  wall (pass 1) : %.1f ms  (%.2f M msg/s, %.1f ns/msg)\n",
                ns_total / 1e6, static_cast<double>(n1) * 1000.0 / ns_total,
                ns_total / static_cast<double>(n1));
    std::printf("                  (includes a top() call and change-detect per message —\n"
                "                   see bench for isolated book-update cost)\n");

    bool ok = true;

    // ---- determinism: two passes, same bytes ------------------------------
    if (n1 != n2 || s1 != s2 || h1.checkpoints.size() != h2.checkpoints.size()) {
        std::printf("\n  [FAIL] two passes over the same file disagree\n");
        std::printf("         pass1 %zu msgs 0x%016llx | pass2 %zu msgs 0x%016llx\n",
                    n1, (unsigned long long)s1, n2, (unsigned long long)s2);
        ok = false;
    } else {
        for (std::size_t i = 0; i < h1.checkpoints.size(); ++i) {
            if (h1.checkpoints[i].checksum != h2.checkpoints[i].checksum) {
                std::printf("\n  [FAIL] passes diverge at checkpoint %zu (message %zu)\n",
                            i, h1.checkpoints[i].msg_index);
                ok = false;
                break;
            }
        }
        if (ok) std::printf("  [ OK ] two independent passes produce identical state\n");
    }

    // ---- golden comparison ------------------------------------------------
    std::vector<Checkpoint> gold;
    std::uint64_t gold_final = 0;
    if (golden != "/dev/null" && read_golden(golden, gold, gold_final) && !gold.empty()) {
        bool gok = true;
        if (gold.size() != h1.checkpoints.size()) {
            std::printf("  [FAIL] golden has %zu checkpoints, this run has %zu\n"
                        "         (different input file, or kCheckpointEvery changed)\n",
                        gold.size(), h1.checkpoints.size());
            gok = false;
        } else {
            for (std::size_t i = 0; i < gold.size(); ++i) {
                const auto& g = gold[i];
                const auto& c = h1.checkpoints[i];
                if (g.checksum != c.checksum || g.bid_px != c.bid_px ||
                    g.bid_qty != c.bid_qty || g.ask_px != c.ask_px ||
                    g.ask_qty != c.ask_qty) {
                    std::printf("\n  [FAIL] golden mismatch at message %zu\n", c.msg_index);
                    std::printf("         golden  0x%016llx  bid %u x %u | ask %u x %u\n",
                                (unsigned long long)g.checksum, g.bid_px, g.bid_qty,
                                g.ask_px, g.ask_qty);
                    std::printf("         current 0x%016llx  bid %u x %u | ask %u x %u\n",
                                (unsigned long long)c.checksum, c.bid_px, c.bid_qty,
                                c.ask_px, c.ask_qty);
                    std::printf("         this is the FIRST divergence — everything before it agreed\n");
                    gok = false;
                    break;
                }
            }
        }
        if (gok) {
            std::printf("  [ OK ] matches golden file (%zu checkpoints)\n", gold.size());
        } else {
            ok = false;
        }
    } else if (golden != "/dev/null") {
        write_golden(golden, h1.checkpoints, s1);
        std::printf("  [NEW] wrote golden file %s (%zu checkpoints) — commit it\n",
                    golden.c_str(), h1.checkpoints.size());
    }

    const auto& st = b1.stats();
    std::printf("\n  final checksum: 0x%016llx\n", (unsigned long long)s1);
    std::printf("  top-of-book changes : %zu  (%.1f%% of messages)\n", h1.tob_changes,
                100.0 * static_cast<double>(h1.tob_changes) / static_cast<double>(n1));
    std::printf("  best-price rescans  : %llu\n", (unsigned long long)st.best_recomputes);
    std::printf("  resting orders      : %zu across %zu bid / %zu ask levels\n",
                b1.live_orders(), b1.bid_levels(), b1.ask_levels());
    std::printf("  pool high water     : %zu of %zu\n", b1.pool_high_water(), std::size_t{1} << 21);
    std::printf("  anomalies           : %llu unknown-ref, %llu out-of-range, %llu pool-exhausted,"
                " %llu length-mismatch\n",
                (unsigned long long)st.unknown_ref,
                (unsigned long long)st.price_out_of_range,
                (unsigned long long)st.pool_exhausted,
                (unsigned long long)h1.length_mismatches);

    std::printf("\n%s\n", ok ? "REPLAY IS DETERMINISTIC."
                             : "REPLAY IS NOT DETERMINISTIC — investigate before trusting anything.");
    return ok ? 0 : 1;
}
