// lob/bench.hpp — measurement infrastructure.
//
// The three ways a micro-benchmark lies to you, and the fix for each:
//
//  1. Dead-code elimination. If nothing observes the result, the compiler
//     deletes the work. Fix: `sink()` — an inline-asm barrier that makes the
//     value appear escaped without emitting any instruction.
//
//  2. Loop-invariant hoisting. If the input is a compile-time constant, the
//     whole computation is folded once. Fix: read inputs from a heap array
//     built at runtime, and `clobber()` between arms.
//
//  3. Drift. Turbo ramp, thermal throttle, and the scheduler make the first
//     arm systematically different from the second. Fix: interleave arms
//     round-robin (A B C A B C ...) and report per-round percentiles, never
//     a single timed pass.
//
// Reporting: never the mean. A mean over a latency distribution with a fat
// tail is a number that describes no observation you actually made. Report
// min / p50 / p90 / p99 / p99.9 / max.

#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

#if defined(__linux__)
#  include <pthread.h>
#  include <sched.h>
#endif

namespace lob {

// --- Optimization barriers -------------------------------------------------

// Force `v` to be materialised. "r,m" lets the compiler keep it in a register
// if it can, memory otherwise. No instruction is emitted.
template <class T>
[[gnu::always_inline]] inline void sink(const T& v) noexcept {
#if defined(__GNUC__)
    asm volatile("" : : "r,m"(v) : "memory");
#endif
}

// Same but for a value the compiler thinks it owns in a register.
template <class T>
[[gnu::always_inline]] inline void sink_rw(T& v) noexcept {
#if defined(__GNUC__)
    asm volatile("" : "+r,m"(v) : : "memory");
#endif
}

// Tell the compiler all of memory changed — kills cross-iteration caching of
// loads it would otherwise prove invariant.
[[gnu::always_inline]] inline void clobber() noexcept {
#if defined(__GNUC__)
    asm volatile("" : : : "memory");
#endif
}

// --- CPU affinity ----------------------------------------------------------

// Pin to a core. Returns false if it failed (containers often forbid this) —
// caller should say so loudly rather than silently reporting noisy numbers.
inline bool pin_to_core(int core) {
#if defined(__linux__)
    if (core < 0) return false;
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(static_cast<unsigned>(core), &set);
    return pthread_setaffinity_np(pthread_self(), sizeof(set), &set) == 0;
#else
    (void)core;
    return false;
#endif
}

// --- Statistics ------------------------------------------------------------

struct Stats {
    double min{}, p50{}, p90{}, p99{}, p999{}, max{}, mean{}, stddev{};
    std::size_t n{};

    static double quantile(std::vector<double>& s, double q) {
        if (s.empty()) return 0.0;
        const double pos = q * static_cast<double>(s.size() - 1);
        const std::size_t lo = static_cast<std::size_t>(pos);
        const std::size_t hi = std::min(lo + 1, s.size() - 1);
        const double frac = pos - static_cast<double>(lo);
        return s[lo] * (1.0 - frac) + s[hi] * frac;
    }

    static Stats from(std::vector<double> samples) {
        Stats st;
        if (samples.empty()) return st;
        std::sort(samples.begin(), samples.end());
        st.n    = samples.size();
        st.min  = samples.front();
        st.max  = samples.back();
        st.p50  = quantile(samples, 0.50);
        st.p90  = quantile(samples, 0.90);
        st.p99  = quantile(samples, 0.99);
        st.p999 = quantile(samples, 0.999);
        double sum = 0.0;
        for (double v : samples) sum += v;
        st.mean = sum / static_cast<double>(st.n);
        double var = 0.0;
        for (double v : samples) { const double d = v - st.mean; var += d * d; }
        st.stddev = std::sqrt(var / static_cast<double>(st.n));
        return st;
    }
};

struct Row {
    std::string label;
    Stats       cycles;   // cycles per tick
    double      ns_per_tick{};
    double      speedup{}; // vs baseline, filled in by the caller
};

inline void print_header(const char* title) {
    std::printf("\n%s\n", title);
    for (std::size_t i = 0; i < 106; ++i) std::putchar('-');
    std::putchar('\n');
    std::printf("%-40s %9s %9s %9s %9s %9s %9s\n",
                "arm", "min", "p50", "p90", "p99", "ns/tick", "vs base");
    for (std::size_t i = 0; i < 106; ++i) std::putchar('-');
    std::putchar('\n');
}

inline void print_row(const Row& r) {
    std::printf("%-40s %9.3f %9.3f %9.3f %9.3f %9.3f %8.2fx\n",
                r.label.c_str(), r.cycles.min, r.cycles.p50, r.cycles.p90,
                r.cycles.p99, r.ns_per_tick, r.speedup);
}

}  // namespace lob
