// lob/refbook.hpp — the oracle.
//
// This is the deliberately boring, obviously-correct implementation:
// std::map of price to std::list of orders, plus an unordered_map index.
// It allocates constantly, chases pointers everywhere, and is roughly 4x
// slower. That is fine. Its job is not to be fast, it is to be so simple that
// a reviewer can convince themselves it is right by reading it.
//
// Every optimisation in book.hpp is then justified by a differential test:
// replay the same messages through both and assert the visible state matches
// after EVERY message. An order book bug is not like a crash — the book stays
// plausible, the strategy keeps trading, and you find out from the P&L three
// weeks later. Differential testing against a slow reference is the cheapest
// insurance available, and it is what makes the fast version trustworthy
// rather than merely fast.
//
// The two implementations must share their ACCEPTANCE RULES, or the diff is
// meaningless: if the fast book rejects a sub-penny price and the reference
// accepts it, every subsequent comparison fails for a reason that has nothing
// to do with the data structures. Hence the identical `acceptable()` check.

#pragma once

#include <cstdint>
#include <functional>
#include <list>
#include <map>
#include <unordered_map>
#include <vector>

#include "lob/book.hpp"

namespace lob {

class RefBook {
public:
    explicit RefBook(std::uint32_t base_price = 0, std::uint32_t tick = 100,
                     std::size_t max_levels = 1u << 16)
        : base_(base_price), tick_(tick), max_levels_(max_levels) {}

    void reset() {
        bids_.clear(); asks_.clear(); index_.clear();
        stats_ = BookStats{};
    }

    void add(std::uint64_t ref, bool is_buy, std::uint32_t shares,
             std::uint32_t price) {
        ++stats_.adds;
        if (!acceptable(price)) { ++stats_.price_out_of_range; return; }
        Side& side = is_buy ? bids_ : asks_;
        auto& lst = side[price];
        lst.push_back(RefOrder{ref, shares, price, is_buy});
        index_[ref] = Loc{price, is_buy, std::prev(lst.end())};
    }

    void cancel(std::uint64_t ref, std::uint32_t shares) {
        ++stats_.cancels;
        auto it = index_.find(ref);
        if (it == index_.end()) { ++stats_.unknown_ref; return; }
        reduce(it, shares);
    }

    void execute(std::uint64_t ref, std::uint32_t shares) {
        ++stats_.executes;
        stats_.exec_shares += shares;
        auto it = index_.find(ref);
        if (it == index_.end()) { ++stats_.unknown_ref; return; }
        reduce(it, shares);
    }

    void remove(std::uint64_t ref) {
        ++stats_.deletes;
        auto it = index_.find(ref);
        if (it == index_.end()) { ++stats_.unknown_ref; return; }
        erase(it);
    }

    void replace(std::uint64_t old_ref, std::uint64_t new_ref,
                 std::uint32_t shares, std::uint32_t price) {
        ++stats_.replaces;
        auto it = index_.find(old_ref);
        if (it == index_.end()) { ++stats_.unknown_ref; return; }
        const bool is_buy = it->second.is_buy;
        erase(it);
        add(new_ref, is_buy, shares, price);
        --stats_.adds;
    }

    TopOfBook top() const {
        TopOfBook t;
        if (!bids_.empty()) {
            t.bid_px = bids_.rbegin()->first;
            t.bid_qty = total(bids_.rbegin()->second);
        }
        if (!asks_.empty()) {
            t.ask_px = asks_.begin()->first;
            t.ask_qty = total(asks_.begin()->second);
        }
        return t;
    }

    void depth(bool is_buy, std::size_t k, std::vector<BookLevel>& out) const {
        out.clear();
        if (is_buy) {
            for (auto it = bids_.rbegin(); it != bids_.rend(); ++it) {
                if (out.size() >= k) break;
                out.push_back({it->first, total(it->second),
                               static_cast<std::uint32_t>(it->second.size())});
            }
        } else {
            for (const auto& [px, lst] : asks_) {
                if (out.size() >= k) break;
                out.push_back({px, total(lst), static_cast<std::uint32_t>(lst.size())});
            }
        }
    }

    // Byte-for-byte identical algorithm to Book::checksum, so the two values
    // are directly comparable.
    std::uint64_t checksum() const {
        std::uint64_t h = 1469598103934665603ULL;
        auto mix = [&h](std::uint64_t v) {
            for (int b = 0; b < 8; ++b) { h ^= (v >> (b * 8)) & 0xFF; h *= 1099511628211ULL; }
        };
        for (auto it = bids_.rbegin(); it != bids_.rend(); ++it) {
            mix(it->first); mix(total(it->second));
            mix(static_cast<std::uint32_t>(it->second.size()));
        }
        mix(0xFFFFFFFFFFFFFFFFULL);
        for (const auto& [px, lst] : asks_) {
            mix(px); mix(total(lst)); mix(static_cast<std::uint32_t>(lst.size()));
        }
        return h;
    }

    std::uint64_t shares_ahead(std::uint64_t ref) const {
        auto it = index_.find(ref);
        if (it == index_.end()) return ~std::uint64_t{0};
        const Side& side = it->second.is_buy ? bids_ : asks_;
        auto lit = side.find(it->second.price);
        if (lit == side.end()) return ~std::uint64_t{0};
        std::uint64_t ahead = 0;
        for (auto o = lit->second.begin(); o != lit->second.end(); ++o) {
            if (o->ref == ref) break;
            ahead += o->qty;
        }
        return ahead;
    }

    std::size_t live_orders() const { return index_.size(); }
    std::size_t bid_levels()  const { return bids_.size(); }
    std::size_t ask_levels()  const { return asks_.size(); }
    const BookStats& stats()  const { return stats_; }

private:
    struct RefOrder {
        std::uint64_t ref;
        std::uint32_t qty;
        std::uint32_t price;
        bool          is_buy;
    };
    using ListIt = std::list<RefOrder>::iterator;
    struct Loc { std::uint32_t price; bool is_buy; ListIt it; };

    // Identical acceptance rule to Book::to_index.
    bool acceptable(std::uint32_t price) const {
        if (price < base_) return false;
        const std::uint32_t d = price - base_;
        if (d % tick_ != 0) return false;
        return (d / tick_) < max_levels_;
    }

    static std::uint32_t total(const std::list<RefOrder>& l) {
        std::uint64_t s = 0;
        for (const auto& o : l) s += o.qty;
        return static_cast<std::uint32_t>(s);
    }

    void reduce(std::unordered_map<std::uint64_t, Loc>::iterator it,
                std::uint32_t shares) {
        auto& o = *it->second.it;
        const std::uint32_t take = shares < o.qty ? shares : o.qty;
        o.qty -= take;
        if (o.qty == 0) erase(it);
    }

    void erase(std::unordered_map<std::uint64_t, Loc>::iterator it) {
        Side& side = it->second.is_buy ? bids_ : asks_;
        auto lit = side.find(it->second.price);
        if (lit != side.end()) {
            lit->second.erase(it->second.it);
            if (lit->second.empty()) side.erase(lit);
        }
        index_.erase(it);
    }

    // Both sides ascending by price; the bid side is simply walked in
    // reverse. Using std::greater for bids would make the two sides distinct
    // types and force every helper to be a template for no benefit.
    using Side = std::map<std::uint32_t, std::list<RefOrder>>;
    Side bids_;
    Side asks_;
    std::unordered_map<std::uint64_t, Loc> index_;

    std::uint32_t base_;
    std::uint32_t tick_;
    std::size_t   max_levels_;
    BookStats     stats_{};
};

}  // namespace lob
