# LOB — Limit Order Book from raw ITCH 5.0

A full-depth limit order book built from Nasdaq TotalView-ITCH 5.0 wire data.
Flat price ladder, intrusive per-level FIFO lists, index-addressed pool
allocator, open-addressing order map, hierarchical occupancy bitmap for
best-price discovery. Zero heap allocation on the hot path.

Every design choice is validated two ways: a **differential test** against a
deliberately naive `std::map` reference book, compared after *every* message,
and a **deterministic replay** with checkpoint checksums against a committed
golden file.

The three most useful things in this repo are bugs, not features. They are in
[Things that went wrong](#things-that-went-wrong).

---

## Quick start

```bash
make data          # generate a spec-conformant synthetic ITCH file
make verify        # fast book vs reference oracle, checked every message
make replay        # deterministic replay + golden checkpoint checksums
make bench         # seven experiments
make determinism   # replay twice, compare checksums
```

GCC ≥ 11 or Clang ≥ 14, C++20, Linux, x86-64. No dependencies.

To run against real data instead: download a daily sample from Nasdaq's
public FTP (`emi.nasdaq.com/ITCH/Nasdaq ITCH/`), gunzip it, and pass the path
to any binary. The parser handles the BinaryFILE framing those files use. Set
the ladder base price for high-priced names — see [Ladder sizing](#ladder-sizing).

---

## Layout

```
include/lob/
  itch.hpp       ITCH 5.0 decode, mmap reader, templated parse loop
  bitmap.hpp     3-level hierarchical occupancy bitmap
  pool.hpp       index-addressed slab pool + open-addressing order map
  book.hpp       the book: ladder, levels, intrusive FIFO lists
  refbook.hpp    the oracle: std::map + std::list + unordered_map
  clock.hpp      RDTSC/RDTSCP with correct fencing, TSC calibration
  bench.hpp      barriers, affinity, percentile stats
src/
  gen_itch.cpp   synthetic ITCH generator with a real price-indexed market model
  verify_main.cpp differential test + bitmap unit test
  replay_main.cpp deterministic replay + golden file
  bench_main.cpp  experiments A-G
```

---

## Structure

```
price ladder (flat array, one Level per tick)
   └─ Level { qty, count, head, tail }              16 B, 4 per cache line
        └─ intrusive doubly-linked FIFO of orders
             └─ Order { next, prev, qty, level|side }  16 B, 4 per cache line
                  (preallocated Pool, addressed by uint32 index)

order_ref (uint64) ──► OrderMap ──► pool index (uint32)
occupancy bitmap  ──► best bid / best ask in O(1)
```

| operation | cost |
|---|---|
| add | O(1) — hash insert, pool alloc, tail append, bitmap set |
| cancel (partial) | O(1) — hash lookup, quantity decrement |
| delete | O(1) — lookup + erase, unlink, pool free, maybe bitmap reset |
| execute | O(1) — lookup, decrement, remove if filled |
| best bid/ask | O(1) — cached; recomputed via bitmap only when a level empties |
| top-K depth | O(K) |
| queue position | O(orders ahead at that level) |

**32-bit indices, not 64-bit pointers.** Halving every link field doubles the
number of orders per cache line. For a list walked on every execution that is
the difference between one cache line and two.

**Side packed into the top bit of the level index.** Keeps `Order` at exactly
16 bytes rather than 20-padded-to-24.

**Prices stay integers.** ITCH gives uint32 with four implied decimals. They
are never converted to floating point anywhere, which is the single largest
source of replay non-determinism in books that get this wrong.

---

## The ITCH layer

Four things about the wire format that bite people, all handled explicitly in
`itch.hpp`:

**Big-endian.** Every multi-byte field. `__builtin_bswap*` compiles to one
instruction, so this is free — but forgetting it produces a book that is
plausible and wrong.

**Unaligned.** Messages are packed with no padding.
`*reinterpret_cast<const uint32_t*>(p + 11)` is undefined behaviour even on
x86 where it appears to work: the compiler may assume alignment and vectorise
accordingly, and it faults outright on ARM. Every field is read through
`memcpy` into a local, which GCC turns into a single `mov`.

**Six-byte timestamps.** 48-bit big-endian nanoseconds since midnight. There
is no 6-byte load, and reading 8 bytes from offset 5 runs past the end of the
shortest message (`Order Delete`, 19 bytes). Composed from a 4-byte and a
2-byte load instead.

**Framing length is authoritative.** The per-type length table is a
cross-check, not the parser's source of truth. A mismatch is counted and
reported rather than assumed away — that is what lets this survive a spec
revision that adds a message type it has never seen.

---

## Verification

`make verify` runs three independent checks.

**1. Bitmap against `std::set`.** 400,000 random set/reset/scan operations,
with indices deliberately biased toward 0, 63, 64, 4095, 4096 and N−1.
Three-level bit twiddling with inclusive and exclusive masks is exactly the
kind of code that is 99% right, and the 1% is a word boundary that fires once
every few million messages.

**2. Fast book against the reference, after every message.** Top of book,
top-20 depth on both sides, live order count; full-ladder checksum and queue
positions at checkpoints. An order book bug does not crash — the book stays
plausible, the strategy keeps quoting, and you find out from the P&L three
weeks later. Differential testing against a slow, obviously-correct reference
is the cheapest insurance available.

**3. Queue position.** Two books can agree on every price and quantity while
disagreeing about who is first in the queue. For a passive strategy that
difference is the entire edge, and it is invisible to an aggregate L2 diff.

Both implementations share identical *acceptance rules* — same sub-tick
rejection, same ladder bounds. Otherwise the diff would fail for reasons that
have nothing to do with the data structures.

```
LOB verification
================
  [ OK ] HierBitmap vs std::set   400000 ops, boundary-weighted
  [ OK ] top-of-book             2000004 messages, checked every message
  [ OK ] top-20 depth both sides 2000004 messages, checked every message
  [ OK ] live order count        2000004 messages, checked every message
  [ OK ] full book checksum      78 checkpoints
  [ OK ] queue position (FIFO)   72682 order comparisons

book state at end of file
  add / delete       : 910698 / 633289
  cancel / execute   : 79851 / 296654
  replace            : 66529
  live orders        : 5039  (ref 5039)
  price levels       : 90 bid / 102 ask  (ref 90 / 102)
  pool high water    : 30008 orders
  best-price rescans : 13367  (0.67% of messages)
  final checksum     : 0x934eb20eaa23c4f9

anomaly counters (all should be 0 on a clean feed)
  unknown order ref  : 0
  price out of range : 0
  pool exhausted     : 0
  length mismatches  : 0

ALL CHECKS PASSED — fast book is equivalent to the reference.
```

### Deterministic replay

Two independent passes over the same bytes must produce identical checkpoint
checksums, and those must match a committed golden file. This catches the four
usual sources of replay drift: floating-point reassociation under different
optimisation levels, unordered-container iteration order leaking into output,
uninitialised padding entering a checksum, and pointer values influencing
behaviour (ASLR then makes every run different).

Checkpoints every 100k messages, not just at end of day. An end-of-day-only
checksum tells you *that* something diverged and nothing about *where*; a
checkpoint series bisects it for you.

```
  [ OK ] two independent passes produce identical state
  final checksum: 0x934eb20eaa23c4f9
  top-of-book changes : 637604  (31.9% of messages)
  REPLAY IS DETERMINISTIC.
```

---

## Results

Intel Xeon @ 2.80 GHz (single vCPU, **virtualised**), Ubuntu 24.04, GCC 13.3,
`-O2 -std=c++20`. 2,000,004 messages / 60.4 MB, 5 interleaved rounds.

> Same caveat as always: this is a shared VM, not a tuned box. Minima and
> relative deltas are stable and reproducible; the far tails are the
> hypervisor's, not this code's.

### A — decode vs decode + book

| arm | ns/msg | cycles/msg | M msg/s |
|---|---:|---:|---:|
| ITCH decode only | 8.07 | 22.6 | 124 |
| ITCH decode + book update | 38.78 | 108.6 | 26 |

Parsing is **21% of end-to-end cost**. This is measured separately precisely
because it is a fixed cost shared by every arm below — folding it in would
compress every ratio toward 1.0 and hide the effects being measured.

### B — flat ladder vs `std::map`

| arm | ns/msg | vs |
|---|---:|---:|
| `std::map` + `std::list` + `unordered_map` | 115.18 | 1.00x |
| flat ladder + pool + open addressing | 33.84 | **3.40x** |

Same message stream, semantics proven identical by `make verify`. `std::map`
is a red-black tree: every node separately allocated, ~48 bytes of overhead
each, and a lookup is 3–5 dependent pointer chases through memory the
allocator scattered. The comparison at each node is cheap; the cache miss
before it is not.

### C — best price: bitmap vs walking the ladder

| arm | min | p50 | p90 | p99 |
|---|---:|---:|---:|---:|
| linear ladder scan | 30.89 | 32.03 | 34.75 | 35.58 |
| 3-level bitmap | 29.29 | 30.54 | 35.34 | 38.04 |

**The bitmap is worth about 5% on throughput here, and the tail claim I
originally made does not reproduce.**

An earlier run of this same benchmark showed the scan variant at p90/p99 of
59.7/72.9 against the bitmap's 43.1/44.7, and I wrote that up as a 1.63x tail
win. Re-running produced the table above, where the ordering at p90/p99 is
*reversed*. That earlier spread was VM noise, not signal, and the honest
conclusion is that this harness does not measure what I claimed.

The reason is a methodology error worth stating plainly: those p90/p99 figures
are quantiles over **5 whole-file replays**, so they describe how variable the
machine was across five multi-second runs. They say nothing about the tail of
an individual `delete` operation, which is the thing the bitmap actually
targets. Aggregating 2 million operations into one mean and then taking a
quantile over five of those means discards exactly the distribution you care
about.

What *is* measured and does hold up:

```
rescans triggered : 13367 (0.67% of messages)
ladder steps walked by the scan variant : 134773 (10.1 per rescan)
```

The mechanical argument stands — the scan's cost is data-dependent and grows
with the gap to the next occupied level, while the bitmap is 3 dependent loads
and 3 bit-scans regardless — but the argument is currently theory plus a step
count, not a measured tail. Proving it needs a per-operation latency
distribution over `delete`/`execute` messages specifically, on a machine
without other tenants. That is the first item in
[Extensions](#extensions), and until it is done the honest summary is: **5% on
throughput, and a tail benefit that is argued rather than demonstrated.**

Both arms still maintain the bitmap; only the search differs. So the 5% is a
lower bound on the throughput effect.

### D — order map, isolated

| arm | ns/msg | vs |
|---|---:|---:|
| `std::unordered_map<uint64,uint32>` | 84.76 | 1.00x |
| open addressing + Fibonacci hash | 23.40 | **3.62x** |

`unordered_map` is a bucket array of pointers to separately allocated nodes:
two cache misses minimum per lookup, plus an allocation on every insert, which
violates the no-malloc-on-the-hot-path rule outright.

Three choices in the replacement matter:

- **Fibonacci hashing** (multiply by 2⁶⁴/φ, take the *high* bits). ITCH order
  references are near-sequential. Taking the low bits of a sequential key would
  cluster catastrophically.
- **Linear probing**, so probe sequences stay inside a cache line and a
  collision is usually free.
- **Backward-shift deletion, not tombstones.** An order book is nothing but
  churn — most orders are cancelled, never executed. With tombstones this map
  would degrade into a linear scan over a trading day.

### E — per-message-type latency

Fenced per operation, timer overhead subtracted. Cycles.

| message | count | min | p50 | p90 | p99 | p99.9 |
|---|---:|---:|---:|---:|---:|---:|
| add | 910,698 | 36 | 260 | 380 | 1050 | 1361 |
| execute | 296,654 | 20 | 114 | 316 | 798 | 1284 |
| cancel | 79,851 | 14 | 160 | 372 | 828 | 1412 |
| delete | 633,289 | 24 | 156 | 346 | 848 | 1324 |
| replace | 66,529 | 90 | 356 | 614 | 1262 | 1645 |

`replace` costs roughly `delete` + `add` because it *is* delete plus add —
and it loses queue priority for the same reason. A strategy that wants to keep
its position in the queue reduces size with a partial cancel instead.

These absolute numbers are inflated: fencing every operation serialises the
pipeline and removes the cross-message overlap that the throughput figures in A
and B benefit from. Read the *shape* here and the *magnitudes* there.

### F — query cost on a warm book

5,039 resting orders across 90 bid / 102 ask levels. Cycles.

| query | min | p50 | p99 |
|---|---:|---:|---:|
| top of book | 2 | 4 | 8 |
| L2 depth, 10 levels | 146 | 148 | 320 |
| L2 depth, 50 levels | 710 | 716 | 824 |
| full-ladder checksum | 15,226 | 15,244 | 27,005 |

Top of book is 4 cycles because it is two cached indices and two loads. A book
that is fast to build but slow to interrogate is not useful — the strategy
reads it far more often than the feed writes it.

### G — capacity sizing

**The single largest effect measured in this project, and it is not an
algorithm.**

| configuration | ns/msg | alloc MB | vs best |
|---|---:|---:|---:|
| pool 2¹⁸ orders, map 2¹⁸ slots | **29.96** | 8 | 1.00x |
| pool 2¹⁸ orders, map 2²⁰ slots | 74.35 | 20 | 2.48x |
| pool 2¹⁸ orders, map 2²² slots | 88.08 | 68 | 2.94x |
| pool 2²¹ orders, map 2¹⁸ slots | 34.27 | 36 | 1.14x |
| pool 2²¹ orders, map 2²² slots | 85.34 | 96 | 2.85x |

Peak live orders in this file: **30,008**. Sizing the map at 4M slots "to be
safe" costs **2.9x throughput**.

The map dominates and the pool barely matters, and the reason is **access
pattern, not size**. A hash spreads lookups uniformly across the entire table,
so the allocation *is* the working set — a 64 MB map means a cache miss plus a
TLB miss on every single lookup. The pool is filled densely from slot 0 upward,
so an oversized pool costs address space and essentially no time.

Corollary worth internalising: **size hash tables tightly and measure; be
generous with anything accessed sequentially.** The instinct to over-provision
"just in case" is correct for the pool and expensive for the map.

---

## Ladder sizing

The flat ladder is 65,536 levels × 16 bytes = 1 MB per side, for a book that is
typically 100 levels deep. That looks profligate and is not: **the allocation
is virtual.** Untouched pages are never faulted in, never occupy physical
memory, and never enter the TLB. The resident set is the few hundred ticks
around the touch — a handful of 4 KB pages. You are trading address space,
which is free on 64-bit, for pointer chasing, which is not.

The real cost is the bounded price range, and it is handled explicitly rather
than hidden:

- `base_price` and `tick` are constructor parameters. Default `tick = 100`
  (one cent in ITCH's 1/10000-dollar units), which is the quoting increment for
  any US equity at or above $1.00 under Reg NMS Rule 612.
- Prices outside the window, or not on a tick boundary, are **rejected and
  counted** (`BookStats::price_out_of_range`), never silently rounded. A book
  that quietly rounds is a book that quietly disagrees with the exchange.
- For a $3,000 name, pass a `base_price` near the open. A production system
  would rebase the ladder on a large gap, or keep a secondary map for
  outliers.

`madvise(MADV_HUGEPAGE)` is requested on the pool and map. At 4 KB pages a
multi-MB randomly-accessed table burns thousands of dTLB entries; 2 MB pages
cut that by ~512x. Advisory — the kernel may decline.

---

## Things that went wrong

### 1. A passing test suite on nonsense input

The first generator kept live orders in a flat vector and cleared stale
"crossed" orders by sampling a few at random each iteration. Stale orders
accumulated faster than random sampling removed them. Within a million messages
the best bid sat **2,000 ticks above the best ask**.

The differential verifier passed the entire time. Both books agreed perfectly —
on a book that was not a market.

The only tell was a counter: `best-price rescans: 0.00% of messages`. The touch
level never emptied, so the bitmap was never exercised, so the central data
structure of the project was covered by a test that reported success.

The fix was to give the generator a real price-indexed model that clears every
level the market moves through, order by order, as executions and cancels — the
actual mechanism. Rescans went from 0.00% to 0.67%.

**A passing differential test proves two implementations agree. It says nothing
about whether your input exercises the paths you built.** Instrument the
code paths you care about and check the counters, not just the assertions.

### 2. An open-addressing map that hangs instead of failing

`make bench` produced no output and did not crash. The process sat at 100% CPU.

Linear probing terminates by finding an empty slot. When the table is full,
there isn't one, and `insert` loops forever. My benchmark harness only erased
on delete and replace — not on executes that take an order to zero — so it
accumulated ~277k entries in a 262,144-slot table.

In a feed handler this failure mode is **worse than a crash**: the process is
alive, the health check passes, and the book silently stops updating. The map
now carries an explicit load ceiling (0.85), an `overflows()` counter surfaced
through `BookStats::map_overflows`, and refuses to hang.

### 3. A tail-latency result that was noise

I reported the bitmap as a 1.63x win at p99 based on one benchmark run. It did
not reproduce — a later run reversed the ordering. The p90/p99 columns in that
experiment are quantiles over five whole-file replays, so they measure how
noisy the VM was across five multi-second runs, not the tail of any individual
operation.

Aggregating 2 million operations into a mean and then taking a quantile across
five of those means throws away the distribution you are trying to see. The
corrected write-up is in [experiment C](#c--best-price-bitmap-vs-walking-the-ladder).
Everything that survived re-running is reported as measured; this one did not,
and it is labelled as such rather than deleted.

### 4. My own defaults were the slowest configuration

The original defaults were `pool = 2²¹, map = 2²²` — chosen by "that seems
safely large". That is the 2.85x row in experiment G. Fixing a constant was
worth more than every algorithmic choice in the book combined.

---

## When this design is wrong

- **Multi-symbol.** One ladder pair per instrument at 2 MB is fine for 50
  symbols and absurd for 8,000. A full-market book needs a shared arena with
  per-symbol slices, or a compact structure for the long tail of illiquid
  names that never have more than 20 levels.
- **Wide or variable tick regimes.** A penny ladder is wrong for futures with
  varying tick sizes by expiry, and wrong for sub-penny quoting under $1.
- **You may not be book-bound.** 43 ns/message is ~23 M msg/s. If the feed
  arrives at 2 M msg/s and the kernel network stack costs 800 ns/packet,
  optimising the book is measuring the wrong thing. Profile first.
- **`std::map` is fine** for a research backtester where clarity beats speed
  and the book is rebuilt once per day. `refbook.hpp` exists for exactly that
  reason and is 100 lines.

---

## Reproducing properly

```bash
isolcpus=2-7 nohz_full=2-7 rcu_nocbs=2-7 intel_pstate=disable   # boot params
sudo cpupower frequency-set -g performance
grep -o 'constant_tsc\|nonstop_tsc' /proc/cpuinfo | sort -u      # must show both
sudo chrt -f 90 taskset -c 3 ./build/bench data/synth.itch 3
```

Then confirm the mechanisms with counters rather than inference:

```bash
perf stat -e cycles,instructions,cache-misses,dTLB-load-misses,\
L1-dcache-load-misses ./build/bench data/synth.itch 3
```

Experiment G's explanation predicts `dTLB-load-misses` should scale with map
size while `L1-dcache-load-misses` on the pool should not. If it doesn't, the
explanation is wrong and the number is a coincidence.

---

## Extensions

1. **Per-operation latency distributions**, not quantiles over whole-file
   replays. This is what experiment C actually needs to support its claim, and
   its absence is why that claim is currently withdrawn.
2. **`perf_event_open` in the harness** — read cache misses and dTLB misses
   per experiment instead of arguing about mechanism.
3. **Real Nasdaq data.** The parser already handles it. Real order flow has
   nothing like a random walk's branch profile, and cross/halt/LULD messages
   exercise paths the generator never produces.
4. **Multi-symbol dispatch** with `stock_locate` → book slice, and a shared
   arena. This is where the current design first breaks.
5. **Snapshot + incremental recovery** — the operationally hard part of a real
   feed handler. Sequence gap detection, snapshot request, and reconciling a
   snapshot against buffered incrementals.
6. **MoldUDP64 framing** and multicast A/B line arbitration, which is how this
   data actually arrives in production rather than as a file.
7. **Fixed-point everywhere** including aggregate quantities, plus a saturating
   `uint32` guard on level quantity.
8. **L3 → L2 conflated snapshot publisher** with a change-detect ring, so
   downstream strategies get top-N updates without re-walking the ladder.

---

## Interview questions this answers

**"How do you build an order book that's fast?"**
Flat ladder instead of a tree (3.40x), open-addressing map instead of
`unordered_map` (3.62x), 32-bit indices instead of pointers, no allocation on
the hot path, and — measured largest of all — size the hash table tightly
because a hash makes the allocation the working set (2.94x).

**"How do you know it's correct?"**
Differential test against a naive `std::map` reference after every message,
including queue position, not just aggregate depth. Plus deterministic replay
against committed checkpoint checksums, so any semantic change fails
immediately and bisects itself.

**"Why the bitmap? Best price is usually one step away."**
Measured, it is worth about 5% on throughput. The argument for it is tail
latency — the scan's cost grows with the gap to the next occupied level and is
longest exactly when the market is sweeping — but I have not demonstrated that
yet, and I withdrew an earlier claim that I had. Rescans fire on 0.67% of
messages and walk 10.1 levels on average; proving the tail case needs a
per-operation distribution on a quiet machine.

**"What went wrong while you built it?"**
Four things, all documented above. The best one: a green test suite running
against a generated book that was persistently crossed by 2,000 ticks — caught
by a performance counter, not an assertion. The most embarrassing: publishing a
1.63x tail result that turned out to be VM noise.
