// ctse/data.hpp — deterministic synthetic tick stream.
//
// Determinism is non-negotiable: the equivalence check between arms only means
// something if both see byte-identical input, and run-to-run comparability
// requires the same stream every time. Hence xoshiro256** with a fixed seed
// rather than std::mt19937 (slower, and its distribution adapters are not
// specified to be portable across implementations).
//
// The generator is not trying to be a realistic price model — it is trying to
// exercise every branch in the strategies at a realistic rate:
//   * GBM-ish random walk for mid, so EMAs cross at a sane frequency
//   * occasional volatility bursts, so the z-score arm actually fires
//   * spread that widens with volatility, so the spread gate flips
//   * skewed queue sizes, so imbalance is not always ~0
// If a branch never flips during the benchmark, you are measuring a branch
// predictor at 100% and your numbers will not survive contact with real data.

#pragma once

#include <cmath>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <new>
#include <vector>

#include "ctse/types.hpp"

namespace ctse::data {

// xoshiro256** — fast, high quality, trivially reproducible.
class Rng {
public:
    explicit Rng(std::uint64_t seed = 0x9E3779B97F4A7C15ULL) noexcept {
        for (auto& x : s_) x = splitmix(seed);
    }

    std::uint64_t next() noexcept {
        const std::uint64_t r = rotl(s_[1] * 5, 7) * 9;
        const std::uint64_t t = s_[1] << 17;
        s_[2] ^= s_[0]; s_[3] ^= s_[1]; s_[1] ^= s_[2]; s_[0] ^= s_[3];
        s_[2] ^= t;     s_[3]  = rotl(s_[3], 45);
        return r;
    }

    // Uniform in [0,1).
    double uniform() noexcept {
        return static_cast<double>(next() >> 11) * 0x1.0p-53;
    }

    // Standard normal via Box-Muller with a cached second variate.
    double normal() noexcept {
        if (have_spare_) { have_spare_ = false; return spare_; }
        double u1 = uniform();
        if (u1 < 1e-300) u1 = 1e-300;
        const double u2 = uniform();
        const double r  = std::sqrt(-2.0 * std::log(u1));
        const double th = 6.283185307179586 * u2;
        spare_ = r * std::sin(th);
        have_spare_ = true;
        return r * std::cos(th);
    }

private:
    static std::uint64_t rotl(std::uint64_t x, int k) noexcept {
        return (x << k) | (x >> (64 - k));
    }
    static std::uint64_t splitmix(std::uint64_t& x) noexcept {
        std::uint64_t z = (x += 0x9E3779B97F4A7C15ULL);
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
        return z ^ (z >> 31);
    }

    std::uint64_t s_[4]{};
    double        spare_{0.0};
    bool          have_spare_{false};
};

// 64B-aligned contiguous tick array. Aligned so the first Tick starts a cache
// line and the hardware prefetcher sees a clean unit stride.
class TickStream {
public:
    explicit TickStream(std::size_t n, std::uint64_t seed = 42) : n_(n) {
        void* raw = ::operator new(n * sizeof(Tick), std::align_val_t{64});
        ticks_ = static_cast<Tick*>(raw);
        generate(seed);
    }
    ~TickStream() { ::operator delete(ticks_, std::align_val_t{64}); }

    TickStream(const TickStream&) = delete;
    TickStream& operator=(const TickStream&) = delete;

    const Tick*  data() const noexcept { return ticks_; }
    std::size_t  size() const noexcept { return n_; }
    const Tick&  operator[](std::size_t i) const noexcept { return ticks_[i]; }
    std::size_t  bytes() const noexcept { return n_ * sizeof(Tick); }

private:
    void generate(std::uint64_t seed) {
        Rng rng(seed);

        double mid       = 24000.0;   // e.g. an index future
        double vol       = 0.00008;   // per-tick sigma of log-return
        double tick_size = 0.05;
        std::uint64_t ts = 34200000000000ULL;  // 09:30:00.000000000

        for (std::size_t i = 0; i < n_; ++i) {
            // Volatility regime: rare bursts that decay. Keeps the z-score
            // strategy from sitting in its deadband for the whole run.
            if (rng.uniform() < 0.0008) vol *= 3.5;
            vol = 0.00008 + (vol - 0.00008) * 0.9995;

            mid *= std::exp(vol * rng.normal());

            // Spread widens with vol; floor at one tick, quantise to ticks.
            const double raw_spread = tick_size * (1.0 + 40000.0 * vol * rng.uniform());
            double half = 0.5 * std::max(tick_size, raw_spread);
            half = std::round(half / tick_size) * tick_size;

            const double bid = std::round((mid - half) / tick_size) * tick_size;
            const double ask = std::round((mid + half) / tick_size) * tick_size;

            // Queue sizes: lognormal-ish with a persistent skew so imbalance
            // has autocorrelation instead of being white noise.
            const double skew = 0.5 + 0.5 * std::sin(static_cast<double>(i) * 0.0007);
            const auto bq = static_cast<std::uint32_t>(
                10.0 + 4000.0 * skew * rng.uniform() + 1.0);
            const auto aq = static_cast<std::uint32_t>(
                10.0 + 4000.0 * (1.0 - skew) * rng.uniform() + 1.0);

            ts += 1000ULL + static_cast<std::uint64_t>(rng.uniform() * 50000.0);

            ticks_[i] = Tick{
                ts,
                static_cast<std::uint32_t>(i % 8),          // 8 instruments
                static_cast<std::uint32_t>(i),
                bid, ask,
                (rng.uniform() < 0.5 ? bid : ask),          // trade at a side
                bq, aq,
                static_cast<std::uint32_t>(1 + rng.uniform() * 200.0),
                0u
            };
        }
    }

    Tick*       ticks_{nullptr};
    std::size_t n_{0};
};

}  // namespace ctse::data
