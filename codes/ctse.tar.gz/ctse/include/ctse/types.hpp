// ctse/types.hpp — Core wire-shaped POD types.
//
// Design notes
// ------------
// * `Tick` is exactly one cache line (64B) and 64B-aligned so a tick never
//   straddles two lines. Straddling doubles the L1 fill cost on the hot path
//   and is one of the cheapest wins available in a feed handler.
// * Everything is trivially copyable + constexpr-friendly. No virtual bases,
//   no std::string, no heap. This lets the whole struct live in a flat array
//   the prefetcher can walk linearly.
// * Accessors are constexpr and marked always_inline: we want them folded into
//   the strategy body, not emitted as calls.

#pragma once

#include <cstddef>
#include <cstdint>
#include <type_traits>

namespace ctse {

#if defined(__GNUC__)
#  define CTSE_ALWAYS_INLINE [[gnu::always_inline]] inline
#  define CTSE_NOINLINE      [[gnu::noinline]]
#  define CTSE_HOT           [[gnu::hot]]
#  define CTSE_PURE          [[gnu::pure]]
#else
#  define CTSE_ALWAYS_INLINE inline
#  define CTSE_NOINLINE
#  define CTSE_HOT
#  define CTSE_PURE
#endif

inline constexpr std::size_t kCacheLine = 64;

enum class Side : std::uint8_t { None = 0, Buy = 1, Sell = 2 };

// ---------------------------------------------------------------------------
// Tick — one normalised top-of-book update. 64 bytes, one cache line.
// ---------------------------------------------------------------------------
struct alignas(kCacheLine) Tick {
    std::uint64_t ts_ns;          // exchange timestamp
    std::uint32_t instrument_id;  // dense id, index into per-instrument state
    std::uint32_t seq;            // gap detection
    double        bid;
    double        ask;
    double        last;
    std::uint32_t bid_qty;
    std::uint32_t ask_qty;
    std::uint32_t last_qty;
    std::uint32_t flags;

    CTSE_ALWAYS_INLINE constexpr double mid() const noexcept {
        return 0.5 * (bid + ask);
    }
    CTSE_ALWAYS_INLINE constexpr double spread() const noexcept {
        return ask - bid;
    }
    // Queue imbalance in [-1, +1]. +1 == all bid, -1 == all ask.
    CTSE_ALWAYS_INLINE constexpr double imbalance() const noexcept {
        const double b = static_cast<double>(bid_qty);
        const double a = static_cast<double>(ask_qty);
        const double d = b + a;
        return d > 0.0 ? (b - a) / d : 0.0;
    }
};

static_assert(sizeof(Tick) == 64, "Tick must be exactly one cache line");
static_assert(alignof(Tick) == 64, "Tick must be cache-line aligned");
static_assert(std::is_trivially_copyable_v<Tick>);
static_assert(std::is_trivially_destructible_v<Tick>);

// ---------------------------------------------------------------------------
// Signal — what a strategy emits per tick. 16 bytes, fits in one XMM pair,
// returned in registers rather than via a hidden pointer (sret).
// ---------------------------------------------------------------------------
struct Signal {
    double        strength;     // [-1, +1]; sign carries direction
    Side          side;
    std::uint8_t  confidence;   // 0..255
    std::uint16_t strategy_id;  // which leg produced it
    std::uint32_t _pad;

    CTSE_ALWAYS_INLINE constexpr bool active() const noexcept {
        return side != Side::None;
    }
};

static_assert(sizeof(Signal) == 16);
static_assert(std::is_trivially_copyable_v<Signal>);

CTSE_ALWAYS_INLINE constexpr Signal no_signal() noexcept {
    return Signal{0.0, Side::None, 0, 0, 0};
}

// Deterministic combiner used identically by every engine arm, so the only
// thing the benchmark can possibly be measuring is dispatch.
// Rule: strongest absolute strength wins; ties broken by lower strategy_id.
CTSE_ALWAYS_INLINE constexpr Signal combine(const Signal& a,
                                            const Signal& b) noexcept {
    const double aa = a.strength < 0.0 ? -a.strength : a.strength;
    const double ab = b.strength < 0.0 ? -b.strength : b.strength;
    if (ab > aa) return b;
    if (aa > ab) return a;
    return (b.strategy_id < a.strategy_id) ? b : a;
}

}  // namespace ctse
