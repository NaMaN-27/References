// ctse/clock.hpp — TSC-based timing.
//
// Why not std::chrono::steady_clock?
//   clock_gettime via vDSO costs ~20-25ns. When the thing you are measuring is
//   2-15ns, the instrument dominates the measurement. RDTSC is ~6-8 cycles and
//   RDTSCP ~24-32, both far cheaper and, critically, *stable* enough that the
//   overhead can be measured once and subtracted.
//
// Serialization, precisely:
//   RDTSC is not ordered against surrounding instructions. Out-of-order
//   execution can hoist it above the code under test or sink it below.
//   - Opening fence: LFENCE ; RDTSC        (nothing before can sink past it)
//   - Closing fence: RDTSCP ; LFENCE       (RDTSCP waits for prior ops to
//                                           retire; LFENCE stops later ops
//                                           from being hoisted above it)
//   CPUID+RDTSC is the older recipe but CPUID is a VM exit under many
//   hypervisors and costs hundreds of cycles with high variance. Prefer
//   LFENCE on anything post-Nehalem with the `rdtscp` + `constant_tsc` flags.
//
// Requirements: check /proc/cpuinfo for `constant_tsc` and `nonstop_tsc`.
// Without them the TSC changes rate with P-states and every number is fiction.

#pragma once

#include <cstdint>
#include <chrono>
#include <thread>
#include <algorithm>
#include <vector>

#if defined(__x86_64__) || defined(_M_X64)
#  include <x86intrin.h>
#  define CTSE_HAS_TSC 1
#else
#  define CTSE_HAS_TSC 0
#endif

namespace ctse {

#if CTSE_HAS_TSC

// Open a timed region. LFENCE then RDTSC.
[[gnu::always_inline]] inline std::uint64_t tsc_begin() noexcept {
    _mm_lfence();
    return __rdtsc();
}

// Close a timed region. RDTSCP (waits for retirement) then LFENCE.
[[gnu::always_inline]] inline std::uint64_t tsc_end() noexcept {
    unsigned aux;
    const std::uint64_t t = __rdtscp(&aux);
    _mm_lfence();
    return t;
}

// Unfenced read — use only for coarse, long regions where the fence cost
// would itself perturb the measurement.
[[gnu::always_inline]] inline std::uint64_t tsc_raw() noexcept {
    return __rdtsc();
}

#else  // portable fallback

inline std::uint64_t tsc_begin() noexcept {
    return static_cast<std::uint64_t>(
        std::chrono::steady_clock::now().time_since_epoch().count());
}
inline std::uint64_t tsc_end() noexcept { return tsc_begin(); }
inline std::uint64_t tsc_raw() noexcept { return tsc_begin(); }

#endif

// ---------------------------------------------------------------------------
// Calibration: how many TSC ticks per nanosecond.
// Measure against CLOCK_MONOTONIC over a window long enough to swamp the
// syscall jitter. 200ms is plenty; take the median of several runs.
// ---------------------------------------------------------------------------
inline double calibrate_tsc_ghz(int trials = 5, int window_ms = 60) {
    std::vector<double> samples;
    samples.reserve(static_cast<std::size_t>(trials));

    for (int i = 0; i < trials; ++i) {
        const auto wall0 = std::chrono::steady_clock::now();
        const std::uint64_t t0 = tsc_end();

        std::this_thread::sleep_for(std::chrono::milliseconds(window_ms));

        const std::uint64_t t1 = tsc_end();
        const auto wall1 = std::chrono::steady_clock::now();

        const double ns = std::chrono::duration<double, std::nano>(
                              wall1 - wall0).count();
        if (ns > 0.0) samples.push_back(static_cast<double>(t1 - t0) / ns);
    }
    if (samples.empty()) return 1.0;
    std::sort(samples.begin(), samples.end());
    return samples[samples.size() / 2];  // ticks per nanosecond == GHz
}

// Measured cost of an empty tsc_begin/tsc_end pair, so it can be subtracted
// from per-operation measurements. Returns the *minimum* observed, which is
// the cleanest estimate of the instrument's own cost.
inline std::uint64_t measure_timer_overhead(int iters = 20000) {
    std::uint64_t best = ~std::uint64_t{0};
    for (int i = 0; i < iters; ++i) {
        const std::uint64_t a = tsc_begin();
        const std::uint64_t b = tsc_end();
        const std::uint64_t d = b - a;
        if (d < best) best = d;
    }
    return best;
}

}  // namespace ctse
