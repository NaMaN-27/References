// ctse/indicators.hpp — stateful indicator primitives.
//
// Every window size is a *non-type template parameter*, not a constructor
// argument. That is the whole point of the exercise and it buys three things
// a runtime size cannot:
//
//   1. The ring buffer is a fixed-size array member. No pointer indirection,
//      no separate allocation, and the state lives inline in the strategy
//      object — so the strategy object itself can be one cache line.
//   2. Modulo becomes a mask. `i & (N-1)` is one AND; `i % n` with runtime n
//      is a 20-40 cycle integer divide. Enforced by static_assert.
//   3. Coefficients like the EMA alpha become compile-time constants the
//      compiler can fold into the FMA immediately, and short loops fully
//      unroll.
//
// The cost: a distinct instantiation per parameter set, so binary size and
// compile time grow. That trade is correct for a handful of hot strategies
// and wrong for a config-driven system with hundreds of variants. Say so in
// an interview — the trade-off is the answer, not the technique.

#pragma once

#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>

#include "ctse/types.hpp"

namespace ctse::ind {

inline constexpr bool is_pow2(std::size_t n) noexcept {
    return n != 0 && (n & (n - 1)) == 0;
}

// ---------------------------------------------------------------------------
// RollingWindow<T, N> — power-of-two ring with O(1) rolling sum.
// Sum is maintained incrementally: add the new, subtract the evicted. That is
// one add and one subtract per tick instead of an N-element re-sum.
//
// Numerical caveat, and it matters in production: incremental float sums drift
// because the subtraction is not the exact inverse of the earlier addition.
// Over millions of ticks the error accumulates. Mitigations, in order of cost:
//   (a) periodic full recompute every K ticks (cheap, what we do here),
//   (b) Kahan/Neumaier compensated summation,
//   (c) integer/fixed-point accumulation (correct, and what real systems use
//       for prices — store paise/ticks as int64, not double).
// ---------------------------------------------------------------------------
template <class T, std::size_t N>
class RollingWindow {
    static_assert(is_pow2(N), "N must be a power of two so % becomes &");

public:
    static constexpr std::size_t kSize = N;
    static constexpr std::size_t kMask = N - 1;
    static constexpr std::uint64_t kRecomputeEvery = 1u << 20;

    CTSE_ALWAYS_INLINE void push(T v) noexcept {
        const T evicted = buf_[head_ & kMask];
        buf_[head_ & kMask] = v;
        ++head_;
        if (count_ < N) { ++count_; sum_ += v; }
        else            { sum_ += v - evicted; }

        if ((head_ & (kRecomputeEvery - 1)) == 0) [[unlikely]] recompute();
    }

    CTSE_ALWAYS_INLINE T sum()  const noexcept { return sum_; }
    CTSE_ALWAYS_INLINE bool full() const noexcept { return count_ >= N; }
    CTSE_ALWAYS_INLINE std::size_t count() const noexcept { return count_; }

    CTSE_ALWAYS_INLINE T mean() const noexcept {
        return count_ ? sum_ / static_cast<T>(count_) : T{};
    }
    // Most recent value pushed.
    CTSE_ALWAYS_INLINE T back() const noexcept {
        return buf_[(head_ - 1) & kMask];
    }
    // Value k pushes ago (k=0 is most recent).
    CTSE_ALWAYS_INLINE T ago(std::size_t k) const noexcept {
        return buf_[(head_ - 1 - k) & kMask];
    }

private:
    CTSE_NOINLINE void recompute() noexcept {
        T s{};
        const std::size_t c = count_ < N ? count_ : N;
        for (std::size_t i = 0; i < c; ++i) s += buf_[(head_ - 1 - i) & kMask];
        sum_ = s;
    }

    std::array<T, N> buf_{};
    T                sum_{};
    std::uint64_t    head_{0};
    std::size_t      count_{0};
};

// ---------------------------------------------------------------------------
// Ema<Period> — alpha is a compile-time constant.
//
// alpha = 2/(period+1) is computed at compile time. Note this cannot be
// `constexpr double` from a call to std::pow in C++17, but plain division is
// fine and constant-folds. The update is a single FMA:
//     ema = ema + alpha*(x - ema)
// which the compiler emits as vfmadd once alpha is an immediate-loaded const.
// ---------------------------------------------------------------------------
template <std::size_t Period>
class Ema {
    static_assert(Period >= 1);

public:
    static constexpr double kAlpha = 2.0 / (static_cast<double>(Period) + 1.0);

    CTSE_ALWAYS_INLINE void push(double x) noexcept {
        if (!primed_) [[unlikely]] { value_ = x; primed_ = true; ++n_; return; }
        value_ += kAlpha * (x - value_);
        ++n_;
    }
    CTSE_ALWAYS_INLINE double value() const noexcept { return value_; }
    // "Warm" once we have seen enough samples for the EMA to have forgotten
    // its seed. 3 periods leaves <5% seed weight.
    CTSE_ALWAYS_INLINE bool warm() const noexcept { return n_ >= 3 * Period; }

private:
    double        value_{0.0};
    std::uint64_t n_{0};
    bool          primed_{false};
};

// ---------------------------------------------------------------------------
// Welford<N> — numerically stable rolling mean/variance over a fixed window.
//
// Textbook Welford is for a *growing* sample. For a sliding window you must
// also remove the evicted point, and naive removal is unstable. Here we keep
// a rolling window plus a rolling sum-of-squares, and periodically recompute
// to bound drift — the pragmatic choice. If you need bit-exactness, use
// integer fixed-point.
// ---------------------------------------------------------------------------
template <std::size_t N>
class RollingMoments {
    static_assert(is_pow2(N));

public:
    CTSE_ALWAYS_INLINE void push(double x) noexcept {
        win_.push(x);
        sq_.push(x * x);
    }
    CTSE_ALWAYS_INLINE bool full() const noexcept { return win_.full(); }
    CTSE_ALWAYS_INLINE double mean() const noexcept { return win_.mean(); }

    CTSE_ALWAYS_INLINE double variance() const noexcept {
        const double m = mean();
        const double v = sq_.mean() - m * m;
        return v > 0.0 ? v : 0.0;
    }
    CTSE_ALWAYS_INLINE double stdev() const noexcept {
        return std::sqrt(variance());
    }
    // z-score of the most recent observation. Guarded against a dead series.
    CTSE_ALWAYS_INLINE double zscore(double eps = 1e-12) const noexcept {
        const double s = stdev();
        return s > eps ? (win_.back() - mean()) / s : 0.0;
    }

private:
    RollingWindow<double, N> win_{};
    RollingWindow<double, N> sq_{};
};

}  // namespace ctse::ind
