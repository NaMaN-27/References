#!/usr/bin/env python3
"""Merge multiple benchmark passes, taking the per-arm minimum.

Why the minimum and not the mean: on a machine you do not fully control, every
measurement is the true cost PLUS a non-negative noise term (interrupts,
steal time, SMT contention, frequency dips). The minimum is the maximum
likelihood estimate of the true cost under that model; the mean is an estimate
of the true cost plus the average amount of interference, which is a property
of the machine's other tenants, not of your code.

Report the min for "what does this code cost" and the p99 for "what will
production see". They answer different questions.
"""
import re
import sys
import glob
import os
from collections import defaultdict

ROW = re.compile(
    r'^(.{1,40}?)\s{2,}([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)x'
)

def parse(path):
    out = {}
    for line in open(path):
        m = ROW.match(line)
        if m:
            out[m.group(1).strip()] = float(m.group(2))   # min cycles/tick
    return out

def main():
    passes = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    cfgs, data, order = [], defaultdict(dict), []
    for path in sorted(glob.glob("results/raw_*_p1.txt")):
        cfgs.append(os.path.basename(path)[4:-7])

    for cfg in cfgs:
        for p in range(1, passes + 1):
            f = f"results/raw_{cfg}_p{p}.txt"
            if not os.path.exists(f):
                continue
            for arm, v in parse(f).items():
                if arm not in order:
                    order.append(arm)
                cur = data[arm].get(cfg)
                data[arm][cfg] = v if cur is None else min(cur, v)

    if not cfgs:
        print("no results found — run scripts/compare_builds.sh first")
        return

    w = 42
    print(f"\nmin cycles/tick across {passes} interleaved passes\n")
    print("arm".ljust(w) + "".join(c.rjust(10) for c in cfgs))
    print("-" * (w + 10 * len(cfgs)))
    for arm in order:
        row = arm.ljust(w)
        for c in cfgs:
            v = data[arm].get(c)
            row += (f"{v:10.2f}" if v is not None else " " * 10)
        print(row)

if __name__ == "__main__":
    main()
