#!/usr/bin/env bash
# Disassemble the probe TU and quantify what the compiler actually emitted.
#
# The benchmark tells you THAT static dispatch is faster. This tells you WHY,
# and it is the part worth being able to talk through: instruction counts,
# call sites, register spills, and whether the FP work got contracted into
# FMAs. Numbers without a mechanism are just a claim.
set -euo pipefail
OBJ="${1:-build/asm_probe.o}"

if [[ ! -f "$OBJ" ]]; then
  echo "missing $OBJ — run: make build/asm_probe.o"; exit 1
fi

DIS=$(mktemp)
objdump -d --no-show-raw-insn -M intel "$OBJ" > "$DIS"

probes=(
  probe_static_single
  probe_virtual_single
  probe_visible_final
  probe_static_chain4
  probe_virtual_chain4
  probe_constexpr_flags
  probe_runtime_flags
)

printf "%-24s %7s %7s %7s %7s %7s %7s\n" \
  "function" "insns" "calls" "indir" "spills" "fma" "vmul"
printf -- "-%.0s" {1..72}; echo

for p in "${probes[@]}"; do
  # Slice the disassembly between this label and the next label.
  body=$(awk -v fn="<$p>:" '
    $0 ~ fn {inside=1; next}
    inside && /^[0-9a-f]+ </ {exit}
    inside {print}
  ' "$DIS")

  [[ -z "$body" ]] && continue

  insns=$(echo "$body"  | grep -cE '^\s+[0-9a-f]+:' || true)
  calls=$(echo "$body"  | grep -cE '^\s+[0-9a-f]+:\s+call' || true)
  indir=$(echo "$body"  | grep -cE '^\s+[0-9a-f]+:\s+call\s+(QWORD PTR|r[a-z0-9]+)' || true)
  # Spills to the stack frame: stores of callee-saved / xmm regs to [rsp/rbp+N]
  spills=$(echo "$body" | grep -cE 'mov(sd|upd|apd|q)?\s+(QWORD PTR|XMMWORD PTR)\s+\[r(sp|bp)' || true)
  fma=$(echo "$body"    | grep -cE 'vfm(add|sub)' || true)
  vmul=$(echo "$body"   | grep -cE 'v?mulsd' || true)

  printf "%-24s %7s %7s %7s %7s %7s %7s\n" \
    "$p" "$insns" "$calls" "$indir" "$spills" "$fma" "$vmul"
done

echo
echo "how to read this:"
echo "  calls == 0        -> the strategy body was inlined into the loop"
echo "  indir  > 0        -> a real vtable dispatch survived"
echo "  high spills       -> the ABI is forcing state through memory each call;"
echo "                       this is usually a bigger cost than the call itself"
echo "  fma == 0 at -O2   -> expected; rebuild with -march=native to get FMAs"
echo
echo "full disassembly kept at: $DIS"
echo "also see build/asm_probe.s for the -S -masm=intel source-interleaved form"
echo
echo "next step — ask the compiler directly why it did or did not inline:"
echo "  g++ -std=c++20 -O2 -Iinclude -c src/asm_probe.cpp -fopt-info-inline-optimized 2>&1 | head -40"
echo "  g++ -std=c++20 -O2 -Iinclude -c src/asm_probe.cpp -fopt-info-inline-missed   2>&1 | head -40"
rm -f /dev/null
