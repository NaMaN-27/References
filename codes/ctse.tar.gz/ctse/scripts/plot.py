#!/usr/bin/env python3
"""Plot benchmark output.  usage:  python3 scripts/plot.py results/bench_O2.txt

Produces results/plots.png with three panels:
  1. cycles/tick by arm, grouped by experiment
  2. chain-length scaling, virtual vs static, with the per-leg tax annotated
  3. absolute dispatch tax per leg vs chain length

Deliberately matplotlib-only, no seaborn: one fewer dependency to install on a
box you do not own.
"""
import re
import sys
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROW = re.compile(
    r'^(.{1,40}?)\s{2,}([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)x'
)
HDR = re.compile(r'^EXPERIMENT (\w) — (.+)$')


def parse(path):
    experiments, cur = {}, None
    for line in open(path):
        h = HDR.match(line.strip())
        if h:
            cur = f"{h.group(1)}: {h.group(2)}"
            experiments[cur] = []
            continue
        m = ROW.match(line)
        if m and cur:
            experiments[cur].append({
                "arm": m.group(1).strip(),
                "min": float(m.group(2)),
                "p50": float(m.group(3)),
                "p90": float(m.group(4)),
                "p99": float(m.group(5)),
            })
    return experiments


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "results/bench_O2.txt"
    exp = parse(path)
    if not exp:
        print(f"no parseable rows in {path}")
        return

    fig = plt.figure(figsize=(13, 12))

    # --- panel 1: every arm, min with p99 as an error bar ------------------
    ax = fig.add_subplot(3, 1, 1)
    labels, mins, errs, colors = [], [], [], []
    for name, rows in exp.items():
        for r in rows:
            labels.append(f"[{name[0]}] {r['arm']}")
            mins.append(r["min"])
            errs.append(max(0.0, r["p99"] - r["min"]))
            colors.append("#c0392b" if "virtual" in r["arm"] or "runtime" in r["arm"]
                          else "#27ae60")
    y = range(len(labels))
    ax.barh(list(y), mins, xerr=errs, color=colors, alpha=0.85,
            error_kw={"ecolor": "#555", "capsize": 2, "lw": 0.8})
    ax.set_yticks(list(y))
    ax.set_yticklabels(labels, fontsize=7)
    ax.invert_yaxis()
    ax.set_xlabel("cycles per tick (bar = min, whisker to p99)")
    ax.set_title("All arms — red = runtime dispatch / runtime flags, green = compile-time",
                 fontsize=10)
    ax.grid(axis="x", alpha=0.3)

    # --- panel 2: chain scaling -------------------------------------------
    ck = next((k for k in exp if k.startswith("C:")), None)
    if ck:
        rows = exp[ck]
        ns = [1, 2, 4, 8][: len(rows) // 2]
        virt = [rows[2 * i]["min"] for i in range(len(ns))]
        stat = [rows[2 * i + 1]["min"] for i in range(len(ns))]

        ax2 = fig.add_subplot(3, 1, 2)
        ax2.plot(ns, virt, "o-", color="#c0392b", label="virtual chain", lw=2)
        ax2.plot(ns, stat, "s-", color="#27ae60", label="static chain", lw=2)
        for x, v, s in zip(ns, virt, stat):
            ax2.annotate(f"{v/s:.2f}x", (x, (v + s) / 2), fontsize=8,
                         ha="center", color="#333")
        ax2.set_xscale("log", base=2)
        ax2.set_xticks(ns)
        ax2.set_xticklabels([str(n) for n in ns])
        ax2.set_xlabel("legs in chain")
        ax2.set_ylabel("cycles per tick")
        ax2.set_title("Chain-length scaling", fontsize=10)
        ax2.legend()
        ax2.grid(alpha=0.3)

        ax3 = fig.add_subplot(3, 1, 3)
        tax = [(v - s) / n for n, v, s in zip(ns, virt, stat)]
        ax3.bar([str(n) for n in ns], tax, color="#e67e22", alpha=0.85)
        for i, t in enumerate(tax):
            ax3.text(i, t, f"{t:.1f}", ha="center", va="bottom", fontsize=9)
        ax3.set_xlabel("legs in chain")
        ax3.set_ylabel("cycles")
        ax3.set_title("Dispatch tax per leg (virtual − static) / N", fontsize=10)
        ax3.grid(axis="y", alpha=0.3)

    fig.tight_layout()
    os.makedirs("results", exist_ok=True)
    out = "results/plots.png"
    fig.savefig(out, dpi=140)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
