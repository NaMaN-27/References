#!/usr/bin/env bash
# Compare build configurations fairly.
#
# Different binaries cannot be interleaved inside one process, so instead we
# alternate whole runs (O2, O3, LTO, native, O2, O3, ...) and take the
# per-arm MINIMUM across passes. Running each binary to completion one after
# the other biases whichever ran while the machine happened to be quiet — on a
# shared or virtualised host that bias is easily 30%, which is larger than the
# effect being measured.
set -euo pipefail
cd "$(dirname "$0")/.."

CORE=${1:-0}
PASSES=${2:-3}
mkdir -p results

BINS=()
[[ -x build/bench        ]] && BINS+=("O2:build/bench")
[[ -x build-o3/bench     ]] && BINS+=("O3:build-o3/bench")
[[ -x build/bench_lto    ]] && BINS+=("LTO:build/bench_lto")
[[ -x build/bench_native ]] && BINS+=("native:build/bench_native")

for p in $(seq 1 "$PASSES"); do
  for entry in "${BINS[@]}"; do
    name="${entry%%:*}"; bin="${entry#*:}"
    echo "pass $p: $name"
    "$bin" "$CORE" > "results/raw_${name}_p${p}.txt" 2>&1
  done
done

python3 scripts/merge_results.py "$PASSES" | tee results/build_comparison.txt
