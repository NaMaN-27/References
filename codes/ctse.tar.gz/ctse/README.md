# CTSE — Compile-Time Strategy Engine

A tick-processing engine where strategy composition is resolved at compile time
via CRTP, templates and `if constexpr`, benchmarked against a functionally
identical `virtual`-dispatch baseline — with the assembly to explain every
number.

The claim under test is not "templates are faster than virtual". That claim is
uselessly vague. The claims actually tested are:

1. Removing an **optimisation barrier** matters far more than removing a
   `call` instruction.
2. Indirect-branch misprediction costs roughly a mispredict penalty per call —
   but **only when the type sequence is unpredictable**, which is a much
   narrower condition than "the code is polymorphic".
3. Compile-time configuration (`if constexpr`) beats a runtime flag by more
   than the cost of the branch, because it also deletes code the optimiser
   would otherwise have to keep alive.
4. Every one of these effects can be **erased by a compiler flag you did not
   know you were setting**, which is the real lesson.

---

## Quick start

```bash
make verify     # prove every arm computes bit-identical signals
make bench      # verify, then run all five experiments
make asm        # disassemble and count calls / spills / FMAs per arm
make compare    # build O2, O3, LTO, native and compare them fairly
make icf        # the trap demo: watch a real 59-cycle effect disappear
python3 scripts/plot.py results/bench_O2.txt
```

Requires GCC ≥ 11 or Clang ≥ 14, C++20, Linux, x86-64. No external
dependencies (matplotlib only for the optional plots).

---

## Repository layout

```
include/ctse/
  types.hpp            Tick (64B, one cache line) and Signal (16B) PODs
  clock.hpp            RDTSC/RDTSCP with correct fencing + TSC calibration
  bench.hpp            optimisation barriers, affinity, percentile stats
  indicators.hpp       NTTP-sized ring window, EMA, rolling moments
  cores.hpp            *** the strategy arithmetic, written exactly once ***
  static_engine.hpp    CRTP base, concept, tuple Chain, if-constexpr toggles
  virtual_engine.hpp   IStrategy, heap Chain, arena Chain, visible/final arm
  data.hpp             deterministic xoshiro256** tick generator
src/
  virtual_impl.cpp     opaque strategy definitions (separate TU, no LTO)
  verify_main.cpp      bit-identical equivalence gate
  bench_main.cpp       the five experiments
  asm_probe.cpp        minimal TU for clean disassembly
scripts/
  inspect_asm.sh       instruction / call / spill / FMA counts per probe
  compare_builds.sh    interleaved multi-pass comparison across build configs
  merge_results.py     per-arm minimum across passes
  plot.py              charts
```

---

## Design: why this benchmark is trustworthy

### The arithmetic exists in exactly one place

`cores.hpp` holds the four strategies' math: EMA crossover, z-score reversion,
book-imbalance momentum, spread gate. **Nothing else computes anything.**

The static arm is a CRTP shell around a core. The virtual arm is a
vtable-bearing shell around the *same* core. Both call `core.step(tick)`. The
arms differ only in how `step` is reached.

The usual way this benchmark goes wrong: someone writes the virtual class with
`double alpha_` as a member and the template class with `static constexpr
kAlpha`, then reports 4x and attributes it to dispatch. Most of that 4x was
constant folding of `alpha`. Sharing the cores makes that mistake impossible.

### `make verify` is a gate, not a nicety

Every arm is run over the same 200k-tick stream and the emitted `Signal`
streams are compared **bit-for-bit**, including the IEEE-754 bit pattern of
`strength`. Not "within tolerance" — tolerance would hide exactly the
structural divergences this test exists to catch.

```
  [ OK ] EmaCross static vs opaque        200000 signals bit-identical
  [ OK ] EmaCross static vs visible       200000 signals bit-identical
  [ OK ] Chain4 static vs opaque          200000 signals bit-identical
  [ OK ] Chain4 static vs arena           200000 signals bit-identical
  [ OK ] Clone4 static vs mono-virtual    200000 signals bit-identical
  [ OK ] Clone4 static vs poly-virtual    200000 signals bit-identical
  [ OK ] Tuned constexpr vs runtime       200000 signals bit-identical
  [ OK ] Chain2 plain vs instrumented     200000 signals bit-identical
  [INFO] signal activity: 77.35% of ticks fire (77086 buy / 77617 sell)
```

That last line matters too. If the strategies never fire, every branch is
one-sided, the predictor is at 100%, and the benchmark is measuring a machine
state that will not exist in production. The generator has volatility regimes
and autocorrelated queue imbalance specifically to keep branches live.

### Three virtual arms, not one

| arm | what it isolates |
|---|---|
| **opaque** — defined only in `virtual_impl.cpp`, no LTO | the realistic case: engine and strategy in different TUs, optimiser blind |
| **visible + `final`** — defined in the header | how much the compiler claws back when it *can* see everything |
| **arena-allocated** — placement-new into one contiguous buffer | separates dispatch cost from allocation-layout cost |

Including the `final` arm is the honest move. It shows the enemy is the
optimisation barrier, not the vtable.

### Methodology

- **RDTSC, not `std::chrono`.** `clock_gettime` costs ~20–25ns through the
  vDSO. When the thing being measured is 8ns, the instrument dominates.
- **Correct fencing.** Open with `LFENCE; RDTSC`, close with `RDTSCP; LFENCE`.
  RDTSC is not ordered against surrounding instructions; without fences the
  CPU will hoist or sink it. `CPUID+RDTSC` is the older recipe but CPUID traps
  to the hypervisor on many VMs and costs hundreds of cycles with awful
  variance.
- **Interleaved round-robin.** Arms run A B C, A B C, A B C… — never A×25 then
  B×25. Sequential execution biases whichever arm ran during turbo ramp or
  thermal throttle. Round-robin makes drift common-mode.
- **Fresh engine object per round**, so both arms see identical warm-up state.
- **Loop-level timing for throughput, per-op timing for distribution**, kept
  separate, with the per-op instrument overhead measured and subtracted.
- **Min for "what does this cost", p99 for "what will production see".** On a
  machine you do not fully control, each sample is the true cost plus a
  non-negative interference term; the min is the maximum-likelihood estimate of
  the truth, the mean estimates the truth plus your neighbours' behaviour.
- **Anti-DCE via a loop-carried checksum**, not a per-iteration memory
  clobber. A `"memory"` barrier inside the loop would force engine state out of
  registers and back through memory — penalising the static arm *specifically*,
  which is the exact effect under test.

---

## Results

Measured on: Intel Xeon @ 2.80 GHz (single vCPU, **virtualised**),
Ubuntu 24.04, GCC 13.3.0, `-O2 -std=c++20`, 524,288 ticks/pass (32 MB working
set), 25 interleaved rounds + 3 warm-up. All figures are **cycles per tick,
lower is better**.

> Caveat, stated up front: this is a shared virtual machine, not a tuned
> low-latency box. There is no `isolcpus`, no `nohz_full`, no C-state pinning,
> and there are other tenants. The **minima and the relative deltas** are
> stable and reproducible; the tails are dominated by the hypervisor and should
> not be quoted as properties of this code. On real hardware, run the same
> binaries with the setup in "Reproducing properly" below.

### A — single strategy, monomorphic call site

| arm | min | p50 | p99 | ns/tick | vs base |
|---|---:|---:|---:|---:|---:|
| virtual, opaque (cross-TU) | 33.40 | 34.25 | 45.86 | 11.93 | 1.00x |
| virtual, visible + `final` | 21.55 | 22.66 | 27.46 | 7.70 | **1.55x** |
| static CRTP | 22.34 | 22.94 | 35.53 | 7.98 | **1.49x** |
| static CRTP + base instrumentation | 21.62 | 21.84 | 28.02 | 7.72 | 1.55x |

**~1.5x, or ~11 cycles/tick.** There is exactly one dynamic type here, so the
BTB is always right and misprediction is not a factor. The entire delta is the
inlining barrier.

Two things worth noticing:

- **`final` ≈ CRTP.** When the compiler can see the concrete type it
  devirtualises and inlines, and virtual dispatch costs nothing. This is the
  most important row in the table for calibrating how much to care.
- **CRTP's shared base behaviour is free.** The instrumented row adds a tick
  counter and a fire counter in the base class, inherited by every strategy
  without any of them writing it, and costs nothing measurable. That is the
  thing plain function templates give you less cleanly.

### B — branch prediction and memory layout, controlled

All rows run **four `EmaCrossCore<8,64,5>` legs**. Identical arithmetic,
identical state size. The clone types differ only in vtable address.

| arm | min | ns/tick |
|---|---:|---:|
| virtual x4, 1 type, fixed cycle | 160.40 | 57.28 |
| virtual x4, 4 types, fixed cycle | 153.17 | 54.70 |
| virtual x4, 1 type, **random order** | 141.85 | 50.66 |
| virtual x4, 4 types, **random order** | **198.45** | 70.87 |
| static x4, identical legs | 69.69 | 24.89 |
| virtual x4 mixed, heap layout | 128.32 | 45.83 |
| virtual x4 mixed, arena layout | 128.94 | 46.05 |

Three findings, two of which contradict the folklore:

**1. Polymorphism in a fixed cycle costs nothing.** Rows 1–2: four distinct
vtable targets visited in the repeating order 0,1,2,3,0,1,2,3… are *not* slower
than one target. A modern ITTAGE-style indirect predictor learns that pattern
perfectly. "Virtual is slow because of branch misprediction" is false for the
common case of a fixed strategy chain.

**2. Polymorphism in an unpredictable order costs ~14 cycles per call.**
Rows 3–4 call the same four legs on every tick but in a random permutation, so
the emitted signal is unchanged and only the target *sequence* becomes
unpredictable:

```
198.45 − 141.85 = +56.6 cycles for 4 calls ≈ 14.2 cycles per call
```

Which is what theory predicts: a 4-way random choice mispredicts ~75% of the
time, and this core's mispredict penalty is ~19 cycles. `0.75 × 19 ≈ 14`.

**3. Heap scatter vs contiguous arena: no measurable difference here.**
Rows 6–7. With four legs, everything stays resident in L1 and the pointer chase
is fully overlapped by out-of-order execution. This effect is real but needs
either many more legs or genuine cache pressure to show up — worth knowing
before you rewrite an allocator to chase it.

### C — chain-length scaling

| legs | virtual | static | ratio | tax total | tax/leg |
|---:|---:|---:|---:|---:|---:|
| 1 | 52.20 | 22.98 | 2.27x | 29.2 | 29.2 |
| 2 | 83.40 | 43.58 | 1.91x | 39.8 | 19.9 |
| 4 | 130.40 | 82.13 | 1.59x | 48.3 | 12.1 |
| 8 | 243.42 | 119.21 | 2.04x | 124.2 | 15.5 |

The **absolute** tax grows monotonically with chain length (29 → 40 → 48 →
124 cycles). The **ratio** does not behave as tidily — it dips at N=4 and
recovers at N=8, because the mixed 4-leg chain includes two cheap legs
(spread gate, imbalance) that dilute the per-leg dispatch cost, and the 8-leg
chain repeats them. This is honest, slightly messy data and it is reported as
measured rather than smoothed into a nicer story.

### D — `if constexpr` vs a runtime flag

| arm | min | ratio |
|---|---:|---:|
| runtime flags, all features on | 64.40 | 1.00x |
| `if constexpr`, all features on | 61.24 | 1.05x |
| runtime flags, only EMA | 32.04 | 1.00x |
| `if constexpr`, only EMA | 22.98 | **1.39x** |

The interesting pair is the second. When the features are *off*, both versions
skip the same work, and every runtime branch is perfectly predicted — yet the
compile-time version is still 39% faster. The gap is not the branch. It is that
the runtime version cannot prove the disabled sub-strategies are dead, so their
state stays live, their constructors run, and the optimiser has to keep the
code paths resident. `if constexpr` deletes them from the program.

### E — per-tick latency distribution (fenced, overhead subtracted)

| arm | min | p50 | p90 | p99 | p99.9 |
|---|---:|---:|---:|---:|---:|
| virtual chain x4 (opaque) | 126 | 144 | 184 | 306 | 827 |
| static chain x4 | 92 | 102 | 146 | 220 | 926 |
| virtual single (opaque) | 38 | 46 | 50 | 106 | 401 |
| static single | 40 | 46 | 50 | 110 | 448 |

**Read the last two rows carefully — they say virtual and static are the same,
and Experiment A said 1.5x.** Both are correct, and the contradiction is the
most useful result in this repo.

The per-op measurement wraps every call in `LFENCE`/`RDTSCP`, which forces
retirement and drains the pipeline at every tick boundary. But the static arm's
advantage is *largely cross-iteration instruction-level parallelism*: with the
body inlined, work from tick N+1 begins before tick N retires. The fence
destroys exactly that. **The instrument removed the effect it was measuring.**

The chain rows still show the gap (126 vs 92) because there is enough *intra*-
tick work for the optimiser to overlap within a single fenced region.

Practical rule: fenced per-operation timing gives you honest tail latency but
systematically understates throughput-oriented optimisations. Measure both,
and know which question you are answering.

---

## Mechanism: what the compiler actually emitted

`make asm` — instruction counts inside each probe loop, `-O2`:

```
function                   insns   calls   indir  spills     fma    vmul
------------------------------------------------------------------------
probe_static_single           77       0       0       0       0       3
probe_virtual_single         103       1       1       1       0       3
probe_visible_final           77       0       0       0       0       3
probe_static_chain4          421       3       0      15       0       8
probe_virtual_chain4         204       2       1      13       0       3
probe_constexpr_flags        418       3       0      19       0       7
probe_runtime_flags          428       3       0      13       0       7
```

- `probe_static_single`: **zero calls, zero spills.** The whole EMA-crossover
  body is spliced into the loop and its state lives in registers across
  iterations.
- `probe_virtual_single`: one indirect call, plus a spill. Note the instruction
  count is *higher* even though the strategy body is elsewhere — that extra
  code is the ABI: marshalling arguments, saving live registers around an
  opaque callee.
- `probe_visible_final`: **byte-identical instruction profile to the static
  version.** Direct proof that devirtualisation fires and that the vtable is
  not the problem.
- `probe_static_chain4` has more in-loop instructions than
  `probe_virtual_chain4` (421 vs 204) for the obvious reason: the static
  version contains all four strategy bodies, the virtual one contains four
  calls to bodies living elsewhere. **Instruction count is not a proxy for
  speed here** — the static version runs at 82 cycles/tick and the virtual at
  130.

With `-march=native` the picture changes as expected — `probe_static_single`
drops to 69 instructions and gains 2 `vfmadd`s, contracting `mul`+`add` pairs
in the EMA update into single FMAs.

Ask GCC directly rather than guessing:

```bash
g++ -std=c++20 -O2 -Iinclude -c src/asm_probe.cpp -fopt-info-inline-optimized
g++ -std=c++20 -O2 -Iinclude -c src/asm_probe.cpp -fopt-info-inline-missed
g++ -std=c++20 -O2 -Iinclude -c src/asm_probe.cpp -fopt-info-vec-missed
```

---

## Cross-build comparison

`make compare` — 3 interleaved passes per configuration, per-arm minimum:

| arm | O2 | O3 | LTO | native |
|---|---:|---:|---:|---:|
| virtual, opaque | 33.40 | 32.33 | 32.69 | 37.09 |
| virtual, visible + final | 21.55 | 21.85 | 22.88 | 27.48 |
| static CRTP | 22.34 | 21.48 | 22.65 | 27.73 |
| virtual x4, 1 type, random | 141.85 | 139.14 | 141.53 | 143.46 |
| virtual x4, 4 types, random | 198.45 | 191.71 | 189.57 | 186.96 |
| **static x4, identical legs** | 69.69 | **41.47** | 69.20 | 51.05 |
| static chain N=8 | 119.21 | 104.66 | 118.12 | 112.15 |
| `if constexpr` (only ema) | 22.98 | 22.63 | 28.27 | 27.12 |

**The `static x4 identical legs` row at -O3 is the headline.** 69.69 → 41.47,
a further **1.68x** on top of the static-vs-virtual win. With four identical
inlined legs, `-O3` hoists `t.mid()` out as a common subexpression and
vectorises the four independent EMA dependency chains into SIMD lanes. The
virtual version cannot access this optimisation at any optimisation level,
because the legs are opaque functions and the compiler cannot prove they are
independent — or even that they are the same function.

That is the strongest argument for the technique, and it is not about `call`
instructions at all. **Inlining is not an optimisation; it is the enabling
condition for every other optimisation.**

Note that LTO did *not* recover the opaque-virtual gap in this configuration.
GCC's speculative devirtualisation is conservative about a base pointer stored
in a struct and returned from a factory. Verify on your own build with
`-fopt-info-inline-optimized` rather than assuming LTO fixes it.

---

## Three ways this benchmark could have lied

### 1. Identical code folding erases polymorphism silently

GCC's `-fipa-icf` (on by default at `-O2`) merges functions with identical
bodies. The four clone types have identical `on_tick` bodies, so ICF collapses
them into one function — every vtable slot points at the same address, the
indirect branch has one target, and the misprediction penalty vanishes while
the code still *looks* polymorphic.

```
$ nm -C --defined-only build/virtual_impl.o     | grep clone | grep on_tick
build/virtual_impl.o     -> 4 distinct addresses
build/virtual_impl_icf.o -> 1 distinct address
```

```
measured polymorphism penalty (random order, poly − mono):
  with ICF disabled (honest) :  +59.27 cycles / 4 calls
  with ICF enabled  (the lie):   −1.73 cycles / 4 calls
```

A real 59-cycle effect, gone. `make icf` reproduces it. I hit this bug in my
own Makefile — the `lto` and `native` targets were initially missing
`-fno-ipa-icf` and reported no polymorphism penalty at all.

### 2. The instrument can destroy the effect

Experiment E, above. Fenced per-op timing understates throughput wins by
serialising the pipeline it is trying to measure.

### 3. Confounding arithmetic with dispatch

The first version of Experiment B compared four `EmaCross` legs against a
mixed chain of four different strategies, and produced an incoherent result:
monomorphic virtual appeared *slower* than polymorphic virtual. It was — the
mixed chain contained two cheap legs and simply did less floating-point work.
The clone types exist entirely to remove that confound.

---

## When NOT to do this

Being able to say this is worth more than the benchmark.

- **Debug builds get slower.** With no inlining, CRTP is a chain of forwarding
  calls. Virtual is often faster at `-O0`.
- **Binary size and I-cache.** Every parameter set is a distinct
  instantiation. Eight strategies × six parameter sets is 48 copies of the code
  competing for L1i. Past some point the win inverts.
- **Compile times.** Deep template composition is measured in minutes on real
  codebases. Non-trivial cost to a team's iteration speed.
- **No runtime configurability.** If strategies are chosen from a config file,
  hot-swapped, or loaded from a shared object, static dispatch is simply the
  wrong tool. A hybrid is usually right: virtual at the outer boundary where
  you need flexibility, static composition inside the hot leaf.
- **The error messages.** Concepts help enormously — that is why the `Strategy`
  concept is there — but this is still template code and a junior on the team
  will pay for it.
- **You may not be call-bound at all.** 11 cycles/tick is ~4ns. If the feed
  handler spends 800ns in the kernel network stack, optimising this is
  measuring the wrong thing. Profile first.

The honest summary: this technique is right for a small, known set of
strategies on a genuinely hot path. It is wrong for a config-driven
backtester, and saying so is the difference between understanding the
trade-off and having read a blog post about it.

---

## Reproducing properly on real hardware

The VM numbers above are directionally right but the tails are noise. On a box
you control:

```bash
# boot params
isolcpus=2-7 nohz_full=2-7 rcu_nocbs=2-7 intel_pstate=disable

# runtime
sudo cpupower frequency-set -g performance
echo 0 | sudo tee /sys/devices/system/cpu/cpufreq/boot_state    # disable turbo
echo 0 | sudo tee /proc/sys/kernel/randomize_va_space           # stable layout
echo 1 | sudo tee /proc/sys/vm/compact_memory

grep -o 'constant_tsc\|nonstop_tsc' /proc/cpuinfo | sort -u   # must show both

sudo chrt -f 90 taskset -c 3 ./build/bench 3
```

Then confirm the mechanism with hardware counters rather than inference:

```bash
perf stat -e cycles,instructions,branch-misses,br_misp_retired.indirect_call,\
L1-icache-load-misses,iTLB-load-misses ./build/bench 3

perf record -e br_misp_retired.indirect_call ./build/bench 3 && perf report
```

If `br_misp_retired.indirect_call` does not drop to ~zero for the static arm,
something is wrong with the build, not with the theory.

---

## Extensions

Roughly in order of value-per-hour:

1. **`perf` counter integration** — read `branch-misses` and
   `icache.ifdata_stall` from inside the harness via `perf_event_open` and
   report them alongside cycles. Turns inference into evidence.
2. **A real feed** — replay ITCH or MDP3.0 instead of synthetic ticks. The
   branch-behaviour profile of real order flow is nothing like a random walk,
   and that is where the interesting surprises live.
3. **Type-erased fallback arm** — a hand-rolled function-pointer table (no
   vtable, no RTTI) and a `std::variant` + `std::visit` arm. `variant` gives
   you a closed type set with static dispatch and a jump table — often the
   right middle ground, and worth measuring.
4. **Expression-template DSL** — let strategies compose with
   `ema(8) - ema(64) > threshold(5_bps)` and build the AST at compile time.
   Large jump in template sophistication; the fun part of the project.
5. **Fixed-point arithmetic** — replace `double` prices with `int64_t` ticks.
   Removes the FP latency chain, makes the incremental rolling sums exactly
   reversible, and eliminates the periodic-recompute hack in
   `RollingWindow`. This is what production systems actually do.
6. **Multi-instrument dispatch** — 8 instruments, per-instrument strategy
   state, and a chunked layout so the working set no longer fits L1. That is
   where the arena-vs-heap effect (currently zero) should finally appear.
7. **Compile-time strategy registry** — a `constexpr` table mapping strategy
   IDs to instantiations, so a config file selects among pre-instantiated
   templates. The pragmatic hybrid, and the design most likely to survive
   contact with a real team.

---

## Interview questions this project answers

**"Why is virtual dispatch slow?"**
Mostly it isn't the `call`. Ranked by measured contribution here: (1) the
optimisation barrier — no inlining means no constant propagation, no CSE
across legs, no vectorisation, plus ABI spills at each call site; (2) indirect
branch misprediction, ~14 cycles per call, *but only when the type sequence is
unpredictable*; (3) memory layout from `vector<unique_ptr<>>`, which measured
at zero in this workload because four legs fit comfortably in L1.

**"When would you use virtual anyway?"**
Runtime-configurable strategy sets, plugin boundaries, anything crossing an
ABI, and every cold path. Also: mark classes `final` and keep them visible and
the compiler devirtualises for free — measured identical to CRTP here.

**"How do you know your benchmark is correct?"**
Shared arithmetic cores, a bit-identical equivalence gate that must pass before
any timing runs, interleaved arms, min-based reporting with an explicit noise
caveat, and a documented case (`make icf`) where a default compiler flag
silently erased a real 59-cycle effect.

**"What does `if constexpr` buy over a runtime flag?"**
More than the branch. It deletes the untaken path from the program, so the
optimiser is not forced to keep dead sub-strategy state alive. Measured 1.39x
in the disabled-features case, where both versions execute the same
instructions.

**"What's the downside of the template approach?"**
Compile time, binary size and I-cache pressure, worse debug builds, no runtime
configurability, and template diagnostics. Concepts fix the diagnostics. The
rest is a real trade you should only take on a path you have profiled.
