// src/asm_probe.cpp — deliberately minimal TU whose only job is to produce
// two comparable disassemblies.
//
// Each function is `noinline` and has external linkage so it survives as its
// own symbol. Then:
//     objdump -d --no-show-raw-insn -M intel build/asm_probe.o
// and count `call` instructions in each loop body.
//
// What to look for:
//   * probe_static_*   : zero `call`. The strategy body is spliced into the
//                        loop. Look for vfmadd / vmulsd / vsubsd inline, and
//                        for the EMA alpha appearing as a loaded constant
//                        rather than a computed value.
//   * probe_virtual_*  : one `call rax` (or `call QWORD PTR [rax+0x10]`) per
//                        leg per tick, preceded by the vptr load. Also note
//                        the register spills around each call site — that is
//                        the ABI tax the static version never pays.
//   * probe_constexpr vs probe_runtime_flags : the runtime version contains
//                        `test`/`jz` pairs on the flag bytes. The constexpr
//                        version has neither the test nor the flag load.
//
// Also worth checking with `-fopt-info-inline-optimized`: GCC will tell you
// exactly which calls it inlined and which it refused to.

#include "ctse/static_engine.hpp"
#include "ctse/virtual_engine.hpp"
#include "ctse/types.hpp"

using namespace ctse;

using SEma  = stat::EmaCross<8, 64, 5>;
using SImb  = stat::Imbalance<16, 30>;
using SZrv  = stat::ZReversion<64, 200>;
using SGate = stat::SpreadGate<20>;
using SChain4 = stat::Chain<SEma, SImb, SZrv, SGate>;

extern "C" {

// --- single strategy -------------------------------------------------------

CTSE_NOINLINE double probe_static_single(SEma* eng, const Tick* t, std::size_t n) {
    double acc = 0.0;
    for (std::size_t i = 0; i < n; ++i) acc += eng->on_tick(t[i]).strength;
    return acc;
}

CTSE_NOINLINE double probe_virtual_single(virt::IStrategy* eng, const Tick* t,
                                          std::size_t n) {
    double acc = 0.0;
    for (std::size_t i = 0; i < n; ++i) acc += eng->on_tick(t[i]).strength;
    return acc;
}

// --- 4-leg chain -----------------------------------------------------------

CTSE_NOINLINE double probe_static_chain4(SChain4* eng, const Tick* t, std::size_t n) {
    double acc = 0.0;
    for (std::size_t i = 0; i < n; ++i) acc += eng->on_tick(t[i]).strength;
    return acc;
}

CTSE_NOINLINE double probe_virtual_chain4(virt::IStrategy** legs, const Tick* t,
                                          std::size_t n) {
    double acc = 0.0;
    for (std::size_t i = 0; i < n; ++i) {
        Signal s = no_signal();
        for (std::size_t k = 0; k < 4; ++k) s = combine(s, legs[k]->on_tick(t[i]));
        acc += s.strength;
    }
    return acc;
}

// --- feature toggles -------------------------------------------------------

CTSE_NOINLINE double probe_constexpr_flags(
        stat::TunedStrategy<stat::Features{true, true, true}, 8, 64>* eng,
        const Tick* t, std::size_t n) {
    double acc = 0.0;
    for (std::size_t i = 0; i < n; ++i) acc += eng->on_tick(t[i]).strength;
    return acc;
}

CTSE_NOINLINE double probe_runtime_flags(stat::TunedStrategyRuntime<8, 64>* eng,
                                         const Tick* t, std::size_t n) {
    double acc = 0.0;
    for (std::size_t i = 0; i < n; ++i) acc += eng->on_tick(t[i]).strength;
    return acc;
}

// --- devirtualisation demo -------------------------------------------------
// Static type is the concrete `final` class, so GCC can prove the dynamic type
// and should devirtualise + inline. Compare against probe_virtual_single.
CTSE_NOINLINE double probe_visible_final(virt::visible::EmaCross<8, 64, 5>* eng,
                                         const Tick* t, std::size_t n) {
    double acc = 0.0;
    for (std::size_t i = 0; i < n; ++i) acc += eng->on_tick(t[i]).strength;
    return acc;
}

}  // extern "C"
