// src/verify_main.cpp — the gate that makes the benchmark meaningful.
//
// Runs every engine arm over the identical tick stream and asserts the emitted
// Signal streams are BIT-identical, including the double bit pattern. If any
// arm diverges, the benchmark is comparing two different computations and its
// numbers mean nothing, so this must be run and pass before bench.
//
// Bit-identical rather than "close enough": both arms call the same core, so
// any difference at all means a real structural divergence (different template
// args, different ordering in the combiner, a reassociation caused by an
// -ffast-math flag applied unevenly). Tolerance would hide exactly the bugs
// this test exists to catch.

#include <cstdio>
#include <cstring>
#include <cstdint>
#include <vector>

#include "ctse/data.hpp"
#include "ctse/static_engine.hpp"
#include "ctse/virtual_engine.hpp"

using namespace ctse;

namespace {

std::uint64_t bits(double d) noexcept {
    std::uint64_t u;
    std::memcpy(&u, &d, sizeof(u));
    return u;
}

bool identical(const Signal& a, const Signal& b) noexcept {
    return bits(a.strength) == bits(b.strength) && a.side == b.side &&
           a.confidence == b.confidence && a.strategy_id == b.strategy_id;
}

template <class Engine>
std::vector<Signal> collect(Engine& e, const data::TickStream& ts) {
    std::vector<Signal> out;
    out.reserve(ts.size());
    for (std::size_t i = 0; i < ts.size(); ++i) out.push_back(e.on_tick(ts[i]));
    return out;
}

bool compare(const char* what, const std::vector<Signal>& ref,
             const std::vector<Signal>& got) {
    if (ref.size() != got.size()) {
        std::printf("  [FAIL] %-32s size %zu vs %zu\n", what, ref.size(), got.size());
        return false;
    }
    for (std::size_t i = 0; i < ref.size(); ++i) {
        if (!identical(ref[i], got[i])) {
            std::printf("  [FAIL] %-32s first divergence at tick %zu\n", what, i);
            std::printf("         ref: strength=%.17g (0x%016llx) side=%u id=%u conf=%u\n",
                        ref[i].strength, (unsigned long long)bits(ref[i].strength),
                        (unsigned)ref[i].side, ref[i].strategy_id, ref[i].confidence);
            std::printf("         got: strength=%.17g (0x%016llx) side=%u id=%u conf=%u\n",
                        got[i].strength, (unsigned long long)bits(got[i].strength),
                        (unsigned)got[i].side, got[i].strategy_id, got[i].confidence);
            return false;
        }
    }
    std::printf("  [ OK ] %-32s %zu signals bit-identical\n", what, ref.size());
    return true;
}

}  // namespace

int main() {
    constexpr std::size_t kN = 200000;
    data::TickStream ts(kN, /*seed=*/42);

    std::printf("CTSE equivalence check  (%zu ticks, %.1f MB)\n",
                ts.size(), static_cast<double>(ts.bytes()) / (1024.0 * 1024.0));

    bool ok = true;

    // ---- single strategy: static vs opaque vs visible ---------------------
    {
        stat::EmaCross<8, 64, 5> s;
        auto ref = collect(s, ts);

        auto vo = virt::make_ema_cross();
        std::vector<Signal> got_o;
        got_o.reserve(kN);
        for (std::size_t i = 0; i < kN; ++i) got_o.push_back(vo->on_tick(ts[i]));
        ok &= compare("EmaCross static vs opaque", ref, got_o);

        virt::visible::EmaCross<8, 64, 5> vv;
        auto got_v = collect(vv, ts);
        ok &= compare("EmaCross static vs visible", ref, got_v);
    }

    // ---- 4-leg chain ------------------------------------------------------
    {
        stat::Chain<stat::EmaCross<8, 64, 5>, stat::Imbalance<16, 30>,
                    stat::ZReversion<64, 200>, stat::SpreadGate<20>> sc;
        auto ref = collect(sc, ts);

        virt::Chain vc;
        for (std::size_t i = 0; i < 4; ++i) vc.add(virt::make_nth(i, 4));
        auto got = collect(vc, ts);
        ok &= compare("Chain4 static vs opaque", ref, got);

        virt::ArenaChain ac;
        ac.emplace<virt::visible::EmaCross<8, 64, 5>>();
        ac.emplace<virt::visible::Imbalance<16, 30>>();
        ac.emplace<virt::visible::ZReversion<64, 200>>();
        ac.emplace<virt::visible::SpreadGate<20>>();
        auto got_a = collect(ac, ts);
        ok &= compare("Chain4 static vs arena", ref, got_a);
    }

    // ---- clone control: 4 distinct types, identical arithmetic ----------
    {
        stat::Chain<stat::EmaCross<8, 64, 5>, stat::EmaCross<8, 64, 5>,
                    stat::EmaCross<8, 64, 5>, stat::EmaCross<8, 64, 5>> sc;
        auto ref = collect(sc, ts);

        virt::Chain mono, poly;
        for (std::size_t i = 0; i < 4; ++i) mono.add(virt::make_ema_clone(0));
        for (std::size_t i = 0; i < 4; ++i) poly.add(virt::make_ema_clone(i));
        ok &= compare("Clone4 static vs mono-virtual", ref, collect(mono, ts));
        ok &= compare("Clone4 static vs poly-virtual", ref, collect(poly, ts));
    }

    // ---- if constexpr vs runtime flags ------------------------------------
    {
        constexpr stat::Features F{true, true, true};
        stat::TunedStrategy<F, 8, 64> a;
        stat::TunedStrategyRuntime<8, 64> b(stat::Features{true, true, true});
        auto ref = collect(a, ts);
        auto got = collect(b, ts);
        ok &= compare("Tuned constexpr vs runtime", ref, got);
    }

    // ---- CRTP instrumented path must not change results -------------------
    {
        stat::Chain<stat::EmaCross<8, 64, 5>, stat::Imbalance<16, 30>> a;
        stat::Chain<stat::EmaCross<8, 64, 5>, stat::Imbalance<16, 30>> b;
        std::vector<Signal> ref, got;
        ref.reserve(kN); got.reserve(kN);
        for (std::size_t i = 0; i < kN; ++i) ref.push_back(a.on_tick(ts[i]));
        for (std::size_t i = 0; i < kN; ++i) got.push_back(b.on_tick_counted(ts[i]));
        ok &= compare("Chain2 plain vs instrumented", ref, got);
    }

    // ---- signal activity sanity: a dead stream would fake a great score ---
    {
        stat::Chain<stat::EmaCross<8, 64, 5>, stat::Imbalance<16, 30>,
                    stat::ZReversion<64, 200>, stat::SpreadGate<20>> sc;
        std::size_t fires = 0, buys = 0, sells = 0;
        for (std::size_t i = 0; i < kN; ++i) {
            const Signal s = sc.on_tick(ts[i]);
            if (s.active()) ++fires;
            if (s.side == Side::Buy) ++buys;
            if (s.side == Side::Sell) ++sells;
        }
        const double rate = 100.0 * static_cast<double>(fires) / static_cast<double>(kN);
        std::printf("  [INFO] signal activity: %.2f%% of ticks fire (%zu buy / %zu sell)\n",
                    rate, buys, sells);
        if (rate < 1.0 || rate > 99.0) {
            std::printf("  [WARN] activity outside 1-99%%: branches may be one-sided,\n"
                        "         which flatters the branch predictor. Retune thresholds.\n");
        }
    }

    std::printf("\n%s\n", ok ? "ALL ARMS EQUIVALENT — benchmark is valid."
                             : "DIVERGENCE DETECTED — benchmark results are INVALID.");
    return ok ? 0 : 1;
}
