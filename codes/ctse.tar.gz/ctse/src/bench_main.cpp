// src/bench_main.cpp — the measurement.
//
// Method
// ------
// Arms are run ROUND-ROBIN, not one-after-another: A B C, A B C, A B C ...
// Sequential execution biases whichever arm runs first (turbo ramp) or last
// (thermal throttle). Round-robin makes drift common-mode and it cancels in
// the comparison.
//
// Each round: fresh engine object, full pass over the tick stream, one
// tsc_begin/tsc_end pair around the whole loop, divide by tick count. Timing
// the whole loop rather than each tick keeps instrument overhead below 0.01%
// of the measurement. The per-tick DISTRIBUTION is measured separately in
// Experiment E, where the overhead is measured and subtracted explicitly.
//
// We report the MINIMUM across rounds as the headline "what this code costs
// when nothing interferes", plus p50/p90/p99 to show how much the machine is
// interfering. On a shared or virtualised host the min is the only number you
// should trust; on a tuned box with isolcpus and nohz_full, p99 becomes
// meaningful too.

#include <cstdio>
#include <cstring>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include "ctse/bench.hpp"
#include "ctse/clock.hpp"
#include "ctse/data.hpp"
#include "ctse/static_engine.hpp"
#include "ctse/virtual_engine.hpp"

using namespace ctse;

namespace {

constexpr std::size_t kTicks  = 1u << 19;   // 524288 ticks = 32 MB, streams L3
constexpr int         kRounds = 25;
constexpr int         kWarmup = 3;

double g_ghz = 1.0;

// --- one timed pass --------------------------------------------------------
//
// The checksum creates a loop-carried dependency on the strategy output, so
// the compiler cannot delete the work. No barrier inside the loop: a "memory"
// clobber per iteration would force the engine state out of registers and
// would penalise the static arm specifically, which is exactly the effect
// under test. One sink after the loop is sufficient and is symmetric.
template <class Engine>
double timed_pass(Engine& eng, const data::TickStream& ts) noexcept {
    const Tick* __restrict__ p = ts.data();
    const std::size_t n = ts.size();

    std::uint64_t chk = 0;
    const std::uint64_t t0 = tsc_begin();
    for (std::size_t i = 0; i < n; ++i) {
        const Signal s = eng.on_tick(p[i]);
        std::uint64_t b;
        std::memcpy(&b, &s.strength, sizeof(b));
        chk = chk * 1099511628211ULL ^ (b + static_cast<std::uint64_t>(s.side));
    }
    const std::uint64_t t1 = tsc_end();
    sink(chk);
    return static_cast<double>(t1 - t0) / static_cast<double>(n);
}

// --- arm plumbing ----------------------------------------------------------
struct Arm {
    std::string                              label;
    std::function<double(const data::TickStream&)> once;
    std::vector<double>                      samples;
};

// pairwise=true: each row is compared to the row above it (rows 0,2,4.. are
// the baselines). Use for A/B pairs. pairwise=false: everything vs row 0.
void run_group(const char* title, std::vector<Arm>& arms,
               const data::TickStream& ts, bool pairwise = false) {
    for (int w = 0; w < kWarmup; ++w)
        for (auto& a : arms) sink(a.once(ts));

    for (int r = 0; r < kRounds; ++r)
        for (auto& a : arms) a.samples.push_back(a.once(ts));

    print_header(title);
    double base_min = 0.0;
    for (std::size_t i = 0; i < arms.size(); ++i) {
        Row row;
        row.label  = arms[i].label;
        row.cycles = Stats::from(arms[i].samples);
        row.ns_per_tick = row.cycles.min / g_ghz;
        if (pairwise) { if (i % 2 == 0) base_min = row.cycles.min; }
        else          { if (i == 0)     base_min = row.cycles.min; }
        row.speedup = base_min > 0.0 ? base_min / row.cycles.min : 1.0;
        print_row(row);
    }
}

// --- type aliases ----------------------------------------------------------
using SEma  = stat::EmaCross<8, 64, 5>;
using SImb  = stat::Imbalance<16, 30>;
using SZrv  = stat::ZReversion<64, 200>;
using SGate = stat::SpreadGate<20>;

using SChain1 = stat::Chain<SEma>;
using SChain2 = stat::Chain<SEma, SImb>;
using SChain4 = stat::Chain<SEma, SImb, SZrv, SGate>;
using SChain8 = stat::Chain<SEma, SImb, SZrv, SGate, SEma, SImb, SZrv, SGate>;
using SChain4Mono = stat::Chain<SEma, SEma, SEma, SEma>;

// A chain that calls all its legs every tick but in an UNPREDICTABLE order,
// driven by a precomputed permutation stream. Because the clone legs are
// arithmetically identical and every leg still sees every tick, the emitted
// signal is order-independent — the computation is unchanged, only the
// indirect-branch target SEQUENCE becomes unpredictable.
//
// This is the experiment that actually stresses the BTB/ITTAGE predictor. A
// plain 4-leg loop visits targets in the fixed cycle 0,1,2,3,0,1,2,3... which
// a modern predictor learns perfectly, so it shows almost no polymorphism
// penalty. Real dispatch is not that tidy.
struct PermChain {
    std::vector<std::unique_ptr<virt::IStrategy>> legs;
    std::vector<std::uint8_t>                     order;   // 4 entries per tick
    std::size_t                                   pos{0};

    CTSE_ALWAYS_INLINE Signal on_tick(const Tick& t) noexcept {
        Signal acc = no_signal();
        const std::uint8_t* o = order.data() + pos;
        acc = combine(acc, legs[o[0]]->on_tick(t));
        acc = combine(acc, legs[o[1]]->on_tick(t));
        acc = combine(acc, legs[o[2]]->on_tick(t));
        acc = combine(acc, legs[o[3]]->on_tick(t));
        pos += 4;
        if (pos + 4 > order.size()) pos = 0;
        return acc;
    }
};

// `distinct==1` builds the monomorphic control: same permutation loads, same
// number of calls, but every target is the same function.
inline PermChain make_perm_chain(std::size_t distinct, std::size_t n_ticks) {
    PermChain c;
    for (std::size_t i = 0; i < 4; ++i)
        c.legs.push_back(virt::make_ema_clone(distinct == 1 ? 0 : i));

    data::Rng rng(7);
    c.order.resize(4 * n_ticks);
    for (std::size_t i = 0; i < n_ticks; ++i) {
        std::uint8_t p[4] = {0, 1, 2, 3};
        for (int k = 3; k > 0; --k) {                    // Fisher-Yates
            const int j = static_cast<int>(rng.next() % static_cast<std::uint64_t>(k + 1));
            std::swap(p[k], p[j]);
        }
        for (int k = 0; k < 4; ++k) c.order[4 * i + static_cast<std::size_t>(k)] = p[k];
    }
    return c;
}

// Build an opaque virtual chain of n legs drawn from `distinct` types.
virt::Chain make_vchain(std::size_t n, std::size_t distinct) {
    virt::Chain c;
    for (std::size_t i = 0; i < n; ++i) c.add(virt::make_nth(i, distinct));
    return c;
}

}  // namespace

int main(int argc, char** argv) {
    const int core = (argc > 1) ? std::atoi(argv[1]) : 0;
    const bool pinned = pin_to_core(core);

    g_ghz = calibrate_tsc_ghz();
    const std::uint64_t timer_ovh = measure_timer_overhead();

    data::TickStream ts(kTicks, 42);

    std::printf("========================================================================\n");
    std::printf(" CTSE — compile-time vs runtime strategy dispatch\n");
    std::printf("========================================================================\n");
    std::printf(" ticks/pass       : %zu  (%.1f MB working set)\n",
                ts.size(), static_cast<double>(ts.bytes()) / (1024.0 * 1024.0));
    std::printf(" rounds           : %d (+%d warmup), interleaved round-robin\n",
                kRounds, kWarmup);
    std::printf(" TSC frequency    : %.4f GHz\n", g_ghz);
    std::printf(" timer overhead   : %llu cycles (lfence;rdtsc .. rdtscp;lfence)\n",
                (unsigned long long)timer_ovh);
    std::printf(" core affinity    : %s\n",
                pinned ? "pinned" : "FAILED — numbers will be noisier than they should be");
#ifdef __OPTIMIZE__
    std::printf(" optimisation     : on\n");
#else
    std::printf(" optimisation     : OFF — results are meaningless, rebuild with -O2\n");
#endif
    std::printf(" all cycle figures are CYCLES PER TICK, lower is better\n");

    // =====================================================================
    // EXPERIMENT A — single strategy. Isolates pure dispatch + inlining with
    // no chain traversal, no allocation layout effects, one dynamic type
    // (so the BTB is always right and branch misprediction is NOT a factor).
    // Any delta here is the inlining barrier, essentially by construction.
    // =====================================================================
    {
        std::vector<Arm> arms;
        arms.push_back({"virtual, opaque (cross-TU)", [](const data::TickStream& s) {
            auto e = virt::make_ema_cross();
            struct W { virt::IStrategy* p;
                       CTSE_ALWAYS_INLINE Signal on_tick(const Tick& t) noexcept {
                           return p->on_tick(t); } } w{e.get()};
            return timed_pass(w, s);
        }, {}});
        arms.push_back({"virtual, visible + final", [](const data::TickStream& s) {
            virt::visible::EmaCross<8, 64, 5> e;
            return timed_pass(e, s);
        }, {}});
        arms.push_back({"static CRTP", [](const data::TickStream& s) {
            SEma e; return timed_pass(e, s);
        }, {}});
        arms.push_back({"static CRTP + base instrumentation", [](const data::TickStream& s) {
            struct W { SEma e;
                       CTSE_ALWAYS_INLINE Signal on_tick(const Tick& t) noexcept {
                           return e.on_tick_counted(t); } } w;
            return timed_pass(w, s);
        }, {}});
        run_group("EXPERIMENT A — single strategy (monomorphic call site)", arms, ts);
    }

    // =====================================================================
    // EXPERIMENT B — indirect-branch prediction, properly controlled.
    //
    // All four rows below run FOUR EmaCrossCore<8,64,5> legs. Identical
    // arithmetic, identical state size, identical everything except how many
    // distinct dynamic types the indirect branch sees. The delta between rows
    // 1 and 2 is therefore attributable to the BTB and nothing else.
    //
    // Rows 3-4 add the static equivalents. Row 4 is the interesting one: with
    // four identical inlined legs the compiler can CSE t.mid() once for the
    // whole chain and interleave the four independent FMA chains, which is a
    // win that has nothing to do with dispatch and everything to do with the
    // optimiser being allowed to see across leg boundaries.
    // =====================================================================
    {
        std::vector<Arm> arms;
        arms.push_back({"virtual x4 Ema, 1 type  (mono)", [](const data::TickStream& s) {
            virt::Chain c;
            for (int i = 0; i < 4; ++i) c.add(virt::make_ema_clone(0));
            return timed_pass(c, s);
        }, {}});
        arms.push_back({"virtual x4 Ema, 4 types (poly)", [](const data::TickStream& s) {
            virt::Chain c;
            for (std::size_t i = 0; i < 4; ++i) c.add(virt::make_ema_clone(i));
            return timed_pass(c, s);
        }, {}});
        arms.push_back({"virtual x4 Ema, 1 type,  random order", [](const data::TickStream& s) {
            auto c = make_perm_chain(1, s.size()); return timed_pass(c, s);
        }, {}});
        arms.push_back({"virtual x4 Ema, 4 types, RANDOM order", [](const data::TickStream& s) {
            auto c = make_perm_chain(4, s.size()); return timed_pass(c, s);
        }, {}});
        arms.push_back({"static  x4 Ema (identical legs)", [](const data::TickStream& s) {
            SChain4Mono c; return timed_pass(c, s);
        }, {}});
        arms.push_back({"static  x4 mixed legs", [](const data::TickStream& s) {
            SChain4 c; return timed_pass(c, s);
        }, {}});
        arms.push_back({"virtual x4 mixed, heap layout", [](const data::TickStream& s) {
            auto c = make_vchain(4, 4); return timed_pass(c, s);
        }, {}});
        arms.push_back({"virtual x4 mixed, arena layout", [](const data::TickStream& s) {
            virt::ArenaChain c;
            c.emplace<virt::visible::EmaCross<8, 64, 5>>();
            c.emplace<virt::visible::Imbalance<16, 30>>();
            c.emplace<virt::visible::ZReversion<64, 200>>();
            c.emplace<virt::visible::SpreadGate<20>>();
            return timed_pass(c, s);
        }, {}});
        run_group("EXPERIMENT B — branch prediction and memory layout, controlled", arms, ts);
        std::printf("\n  rows 1-2: 1 vs 4 targets in a FIXED cycle -> predictor learns it.\n"
                    "  rows 3-4: 1 vs 4 targets in RANDOM order -> the real BTB cost.\n"
                    "  rows 7-8: same work and dispatch, scattered heap vs contiguous\n"
                    "            arena -> pointer-chasing / layout cost.\n");
    }

    // EXPERIMENT C — how the gap scales with chain length.
    // Each virtual leg adds a fixed dispatch + barrier tax. Each static leg
    // adds only its arithmetic, and the compiler can CSE across legs (mid()
    // is computed once for the whole chain, not once per leg). So the ratio
    // should GROW with N, not stay flat.
    // =====================================================================
    {
        std::vector<Arm> arms;
        arms.push_back({"virtual chain N=1", [](const data::TickStream& s) {
            auto c = make_vchain(1, 4); return timed_pass(c, s); }, {}});
        arms.push_back({"static  chain N=1", [](const data::TickStream& s) {
            SChain1 c; return timed_pass(c, s); }, {}});
        arms.push_back({"virtual chain N=2", [](const data::TickStream& s) {
            auto c = make_vchain(2, 4); return timed_pass(c, s); }, {}});
        arms.push_back({"static  chain N=2", [](const data::TickStream& s) {
            SChain2 c; return timed_pass(c, s); }, {}});
        arms.push_back({"virtual chain N=4", [](const data::TickStream& s) {
            auto c = make_vchain(4, 4); return timed_pass(c, s); }, {}});
        arms.push_back({"static  chain N=4", [](const data::TickStream& s) {
            SChain4 c; return timed_pass(c, s); }, {}});
        arms.push_back({"virtual chain N=8", [](const data::TickStream& s) {
            auto c = make_vchain(8, 4); return timed_pass(c, s); }, {}});
        arms.push_back({"static  chain N=8", [](const data::TickStream& s) {
            SChain8 c; return timed_pass(c, s); }, {}});
        run_group("EXPERIMENT C — chain length scaling", arms, ts, /*pairwise=*/true);

        std::printf("\n  per-N ratio (virtual / static, using min):\n");
        for (std::size_t i = 0; i + 1 < arms.size(); i += 2) {
            const double v = Stats::from(arms[i].samples).min;
            const double t = Stats::from(arms[i + 1].samples).min;
            const std::size_t n_legs = std::size_t{1} << (i / 2);
            std::printf("    N=%zu  %6.2fx   (virtual %6.2f, static %6.2f cyc;"
                        " tax %6.2f cyc total, %5.2f cyc/leg)\n",
                        n_legs, v / t, v, t, v - t,
                        (v - t) / static_cast<double>(n_legs));
        }
    }

    // =====================================================================
    // EXPERIMENT D — `if constexpr` vs a runtime flag.
    // Same three features enabled in both. The constexpr version has no flag
    // load and no branch; the runtime version has three of each, all
    // perfectly predicted. This measures the floor cost of a *correctly
    // predicted* branch plus the optimisations it blocks.
    // =====================================================================
    {
        std::vector<Arm> arms;
        arms.push_back({"runtime flags (all on)", [](const data::TickStream& s) {
            stat::TunedStrategyRuntime<8, 64> e(stat::Features{true, true, true});
            return timed_pass(e, s);
        }, {}});
        arms.push_back({"if constexpr (all on)", [](const data::TickStream& s) {
            stat::TunedStrategy<stat::Features{true, true, true}, 8, 64> e;
            return timed_pass(e, s);
        }, {}});
        arms.push_back({"runtime flags (only ema)", [](const data::TickStream& s) {
            stat::TunedStrategyRuntime<8, 64> e(stat::Features{false, false, false});
            return timed_pass(e, s);
        }, {}});
        arms.push_back({"if constexpr (only ema)", [](const data::TickStream& s) {
            stat::TunedStrategy<stat::Features{false, false, false}, 8, 64> e;
            return timed_pass(e, s);
        }, {}});
        run_group("EXPERIMENT D — compile-time vs runtime feature toggles", arms, ts, /*pairwise=*/true);
        std::printf("\n  note: rows 1-2 and rows 3-4 are the meaningful pairs.\n"
                    "  rows 3-4 do less arithmetic, so do not compare across pairs.\n");
    }

    // =====================================================================
    // EXPERIMENT E — per-tick latency distribution.
    // Here the instrument IS significant, so its measured minimum is
    // subtracted. Absolute values are inflated; the SHAPE and the DELTA
    // between arms are what to read. Tail is what matters in trading: a
    // strategy that is 3ns at p50 and 400ns at p99.9 will still miss the fill.
    // =====================================================================
    {
        constexpr std::size_t kSample = 1u << 17;

        auto dist = [&](const char* label, auto&& make) {
            auto eng = make();
            std::vector<double> lat;
            lat.reserve(kSample);
            for (std::size_t i = 0; i < 4096; ++i) sink(eng.on_tick(ts[i]));  // warm
            for (std::size_t i = 0; i < kSample; ++i) {
                const std::uint64_t a = tsc_begin();
                const Signal s = eng.on_tick(ts[i]);
                const std::uint64_t b = tsc_end();
                sink(s);
                const double d = static_cast<double>(b - a) -
                                 static_cast<double>(timer_ovh);
                lat.push_back(d > 0.0 ? d : 0.0);
            }
            const Stats st = Stats::from(std::move(lat));
            std::printf("%-40s %9.1f %9.1f %9.1f %9.1f %9.1f %9.1f\n",
                        label, st.min, st.p50, st.p90, st.p99, st.p999, st.max);
        };

        std::printf("\nEXPERIMENT E — per-tick latency distribution (cycles, timer overhead removed)\n");
        for (int i = 0; i < 106; ++i) std::putchar('-');
        std::printf("\n%-40s %9s %9s %9s %9s %9s %9s\n",
                    "arm", "min", "p50", "p90", "p99", "p99.9", "max");
        for (int i = 0; i < 106; ++i) std::putchar('-');
        std::putchar('\n');

        dist("virtual chain x4 (opaque)", [] { return make_vchain(4, 4); });
        dist("static chain x4", [] { return SChain4{}; });
        dist("virtual single (opaque)", [] {
            struct W {
                std::unique_ptr<virt::IStrategy> p{virt::make_ema_cross()};
                Signal on_tick(const Tick& t) noexcept { return p->on_tick(t); }
            };
            return W{};
        });
        dist("static single", [] { return SEma{}; });

        std::printf("\n  read the tail, not the mean: max is dominated by scheduler\n"
                    "  preemption and page faults, not by your code.\n");
    }

    std::printf("\ndone.\n");
    return 0;
}
