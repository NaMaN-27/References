// src/virtual_impl.cpp — ARM A. Concrete strategies fully hidden from callers.
//
// Nothing here is visible to bench_main.cpp. Without -flto the optimiser
// compiling the benchmark loop sees only `IStrategy::on_tick` as a pure
// virtual slot and must emit a real indirect call. That is the point.
//
// Build the LTO variant too and compare: LTO partially restores the
// information and closes some of the gap. Both numbers are reported.

#include "ctse/virtual_engine.hpp"

namespace ctse::virt {
namespace {

// Note: NOT marked `final`, and in an anonymous namespace inside a TU the
// caller never sees. Deliberately the worst realistic case.
class OpaqueEmaCross : public IStrategy {
public:
    Signal on_tick(const Tick& t) noexcept override { return core_.step(t); }
    std::uint16_t id() const noexcept override { return Core::kId; }
private:
    using Core = core::EmaCrossCore<8, 64, 5>;
    Core core_{};
};

class OpaqueZReversion : public IStrategy {
public:
    Signal on_tick(const Tick& t) noexcept override { return core_.step(t); }
    std::uint16_t id() const noexcept override { return Core::kId; }
private:
    using Core = core::ZReversionCore<64, 200>;
    Core core_{};
};

class OpaqueImbalance : public IStrategy {
public:
    Signal on_tick(const Tick& t) noexcept override { return core_.step(t); }
    std::uint16_t id() const noexcept override { return Core::kId; }
private:
    using Core = core::ImbalanceCore<16, 30>;
    Core core_{};
};

class OpaqueSpreadGate : public IStrategy {
public:
    Signal on_tick(const Tick& t) noexcept override { return core_.step(t); }
    std::uint16_t id() const noexcept override { return Core::kId; }
private:
    using Core = core::SpreadGateCore<20>;
    Core core_{};
};

// Four distinct types, identical arithmetic. Tag only changes the type
// identity (and therefore the vtable), never the computation.
template <int Tag>
class OpaqueEmaClone : public IStrategy {
public:
    Signal on_tick(const Tick& t) noexcept override { return core_.step(t); }
    std::uint16_t id() const noexcept override { return Core::kId; }
private:
    using Core = core::EmaCrossCore<8, 64, 5>;
    Core core_{};
};

}  // namespace

std::unique_ptr<IStrategy> make_ema_clone(std::size_t k) {
    switch (k & 3u) {
        case 0:  return std::make_unique<OpaqueEmaClone<0>>();
        case 1:  return std::make_unique<OpaqueEmaClone<1>>();
        case 2:  return std::make_unique<OpaqueEmaClone<2>>();
        default: return std::make_unique<OpaqueEmaClone<3>>();
    }
}

std::unique_ptr<IStrategy> make_ema_cross()   { return std::make_unique<OpaqueEmaCross>(); }
std::unique_ptr<IStrategy> make_z_reversion() { return std::make_unique<OpaqueZReversion>(); }
std::unique_ptr<IStrategy> make_imbalance()   { return std::make_unique<OpaqueImbalance>(); }
std::unique_ptr<IStrategy> make_spread_gate() { return std::make_unique<OpaqueSpreadGate>(); }

// distinct_types == 1 gives a monomorphic call site (BTB always hits).
// distinct_types == 4 gives a polymorphic one (BTB thrashes).
std::unique_ptr<IStrategy> make_nth(std::size_t i, std::size_t distinct_types) {
    const std::size_t k = distinct_types ? (i % distinct_types) : 0;
    switch (k) {
        case 0:  return make_ema_cross();
        case 1:  return make_imbalance();
        case 2:  return make_z_reversion();
        default: return make_spread_gate();
    }
}

}  // namespace ctse::virt
